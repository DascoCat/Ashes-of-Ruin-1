import {
  SAVE_KEY,
  contractPool,
  foods,
  gearStats,
  hireCosts,
  items,
  nodes,
  petDefs,
  propertyDefs,
  recipes,
  skills,
  stalls,
  workerJobs,
  workerNames,
  zones,
  type Contract,
  type JobId,
  type PetBonus,
  type PropertyId,
  type SkillId,
  type StallId,
  type WorkerTier,
} from "./data";

export type Equip = { weapon: string | null; armor: string | null; tool: string | null; accessory: string | null };
export type Action =
  | { type: "skill"; skill: SkillId; index: number }
  | { type: "combat"; zone: number; index: number };
export type Worker = { id: number; name: string; job: JobId; level: number; xp: number; progress: number; active: boolean; tier?: number };
export type Pet = { id: string; name: string; cost: number; bonus: PetBonus; desc: string };
export type LogKind = "hit" | "hurt" | "eat" | "win" | "lose" | "loot" | "say";
export type LogLine = { k: LogKind; text: string };
export type Splash = { n: number; text: string; k: "foe" | "loot" | "heal" };

export type Save = {
  gold: number;
  hp: number;
  maxhp: number;
  inventory: Record<string, number>;
  levels: Record<SkillId, { xp: number }>;
  equip: Equip;
  unlocked: number[];
  action: Action | null;
  progress: number;
  last: number;
  kills: number;
  achievements: string[];
  autoFood: boolean;
  autoCombat: boolean;
  style: "attack" | "ranged" | "magic";
  battle: { hp: number; guard: boolean } | null;
  turn: number;
  stats: { actions: number; crafted: number; workerActions: number };
  workers: Worker[];
  workerClock: number;
  property: Record<PropertyId, number>;
  pets: Pet[];
  activePet: string | null;
  contractDay: string;
  contractCounts: { kills: number; actions: number; workers: number };
  contractClaimed: string[];
  dailyContracts: Contract[];
  gardenClock: number;
  log: LogLine[];
};

export type Tab =
  | "home"
  | "skills"
  | "detail"
  | "combat"
  | "workers"
  | "property"
  | "market"
  | "pets"
  | "contracts"
  | "items"
  | "map"
  | "extras"
  | "more";

type UI = { tab: Tab; selected: SkillId; toast: string; confirmReset: boolean; pulse: string; pulseN: number; splash: Splash | null };

const listeners = new Set<() => void>();
let rev = 0;
let quiet = false;
let toastTimer = 0;
let booted = false;

function blankLevels(): Save["levels"] {
  return Object.fromEntries(skills.map((s) => [s.id, { xp: 0 }])) as Save["levels"];
}

export function initial(): Save {
  return {
    gold: 125,
    hp: 128,
    maxhp: 128,
    inventory: { wood: 4, fish: 3, oreCopper: 3, food: 2 },
    levels: blankLevels(),
    equip: { weapon: null, armor: null, tool: null, accessory: null },
    unlocked: [0],
    action: null,
    progress: 0,
    last: Date.now(),
    kills: 0,
    achievements: [],
    autoFood: true,
    autoCombat: false,
    style: "attack",
    battle: null,
    turn: 0,
    stats: { actions: 0, crafted: 0, workerActions: 0 },
    workers: [],
    workerClock: 0,
    property: { house: 0, warehouse: 0, workshop: 0, garden: 0 },
    pets: [],
    activePet: null,
    contractDay: "",
    contractCounts: { kills: 0, actions: 0, workers: 0 },
    contractClaimed: [],
    dailyContracts: [],
    gardenClock: 0,
    log: [],
  };
}

let save: Save = initial();
const ui: UI = { tab: "home", selected: "mining", toast: "", confirmReset: false, pulse: "", pulseN: 0, splash: null };

function emit() {
  rev += 1;
  listeners.forEach((l) => l());
}

export function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}
export function getRev() {
  return rev;
}
export function getSave() {
  return save;
}
export function getUI() {
  return ui;
}

export function num(n: number) {
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return Math.floor(n).toLocaleString("pt-BR");
}

export function lvl(id: SkillId) {
  return Math.max(1, Math.floor(Math.sqrt((save.levels[id]?.xp || 0) / 35)) + 1);
}
export function need(id: SkillId) {
  return 35 * lvl(id) * lvl(id);
}
export function pct(id: SkillId) {
  const lv = lvl(id);
  const xp = save.levels[id]?.xp || 0;
  return ((xp - 35 * (lv - 1) ** 2) / (35 * (2 * lv - 1))) * 100;
}
export function totalLevel() {
  return skills.reduce((n, s) => n + lvl(s.id), 0);
}
export function inv(id: string) {
  return save.inventory[id] || 0;
}
export function storageCapacity() {
  return 120 + (save.property.warehouse || 0) * 180 + (save.property.house || 0) * 30;
}
export function usedStorage() {
  return Object.values(save.inventory).reduce((a, b) => a + Math.max(0, b), 0);
}

function activeBonus(): PetBonus | null {
  return save.pets.find((p) => p.id === save.activePet)?.bonus ?? null;
}

export function notify(msg: string) {
  if (quiet) return;
  ui.toast = msg;
  emit();
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => {
    ui.toast = "";
    emit();
  }, 2600);
}

function note(k: LogKind, text: string) {
  if (quiet) return;
  save.log = [{ k, text }, ...(save.log || [])].slice(0, 14);
}

function mark(text: string, splash?: Omit<Splash, "n">) {
  if (quiet) return;
  ui.pulse = text;
  ui.pulseN += 1;
  if (splash) ui.splash = { ...splash, n: ui.pulseN };
}

export function saveNow() {
  save.last = Date.now();
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(save));
  } catch {
    /* private mode */
  }
}

function commit() {
  saveNow();
  emit();
}

function add(id: string, n = 1) {
  if (n <= 0 || id === "gold") {
    save.inventory[id] = Math.max(0, inv(id) + n);
    return true;
  }
  const room = Math.max(0, storageCapacity() - usedStorage());
  if (room <= 0) return false;
  const give = Math.min(n, room);
  save.inventory[id] = inv(id) + give;
  return give === n;
}

function spend(cost: Record<string, number>) {
  if (!Object.entries(cost).every(([k, v]) => inv(k) >= v)) return false;
  Object.entries(cost).forEach(([k, v]) => add(k, -v));
  return true;
}

function gain(id: SkillId, xp: number) {
  if (activeBonus() === "xp") xp = Math.ceil(xp * 1.12);
  const old = lvl(id);
  if (!save.levels[id]) save.levels[id] = { xp: 0 };
  save.levels[id].xp += xp;
  if (lvl(id) > old) notify(`${skills.find((s) => s.id === id)?.name} nível ${lvl(id)}`);
}

export function costText(cost: Record<string, number>) {
  return Object.entries(cost)
    .map(([k, v]) => `${v} ${items[k]?.name || k} (${inv(k)})`)
    .join(" · ");
}

export function playerStats() {
  const w = gearStats[save.equip.weapon || ""] || {};
  const ar = gearStats[save.equip.armor || ""] || {};
  const ac = gearStats[save.equip.accessory || ""] || {};
  return {
    atk: 8 + lvl("attack") * 2 + lvl("strength") * 2 + (w.atk || 0),
    def: 3 + lvl("defense") * 2 + (ar.def || 0) + (ac.def || 0),
    max: 120 + lvl("defense") * 8,
    magic: 4 + lvl("magic") * 2 + (w.mag || 0) + (ac.mag || 0),
  };
}

export function speedMult(skill: SkillId) {
  if (skill !== "mining") return 1;
  return gearStats[save.equip.tool || ""]?.mine ?? 1;
}

export function fmtDur(sec: number) {
  if (!Number.isFinite(sec) || sec < 0) return "—";
  if (sec >= 3600) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return `${h}h ${m.toString().padStart(2, "0")}m`;
  }
  if (sec >= 60) {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}m ${s.toString().padStart(2, "0")}s`;
  }
  return `${sec.toFixed(1).replace(".", ",")}s`;
}

export function actionClock() {
  const a = save.action;
  if (!a) return null;
  const total = a.type === "combat" ? 2.4 : (listFor(a.skill)?.[a.index]?.seconds || 3) * speedMult(a.skill);
  const left = Math.max(0, total * (1 - Math.min(0.999, save.progress)));
  return { total, left };
}

export function levelEta(skill: SkillId) {
  const a = save.action;
  if (!a || a.type !== "skill" || a.skill !== skill) return null;
  const row = listFor(skill)?.[a.index];
  const clock = actionClock();
  if (!row || !clock) return null;
  const xp = activeBonus() === "xp" ? row.xp * 1.12 : row.xp;
  const leftXp = Math.max(0, need(skill) - (save.levels[skill]?.xp || 0));
  if (xp <= 0) return null;
  return (leftXp / xp) * clock.total;
}

function listFor(skill: SkillId) {
  return nodes[skill] || recipes[skill] || null;
}

export function stop() {
  save.action = null;
  save.battle = null;
  save.progress = 0;
  commit();
}

export function startSkill(skill: SkillId, index: number) {
  const row = listFor(skill)?.[index];
  if (!row || lvl(skill) < row.level) return notify("Nível insuficiente.");
  save.action = { type: "skill", skill, index };
  save.progress = 0;
  commit();
}

export function startCombat(zone: number, index: number) {
  if (!save.unlocked.includes(zone)) return notify("Desbloqueie esta região primeiro.");
  const m = zones[zone]?.monsters[index];
  save.action = { type: "combat", zone, index };
  save.progress = 0;
  save.battle = null;
  save.turn = 0;
  if (m) note("say", `Você encara ${m.name}.`);
  commit();
}

function win(zone: number, index: number) {
  const m = zones[zone]?.monsters[index];
  if (!m) return;
  save.kills += 1;
  save.contractCounts.kills = (save.contractCounts.kills || 0) + 1;
  save.gold += m.gold;
  const qty = 1 + Math.floor(Math.random() * 2);
  const placed = add(m.loot, qty);
  if (Math.random() < 0.08) add("gem");
  save.battle = null;
  save.turn = 0;
  save.hp = Math.min(save.maxhp, save.hp + Math.floor(save.maxhp * 0.12));
  const loot = items[m.loot]?.name || m.loot;
  note("win", placed ? `${m.name} cai. +${m.gold} ouro e ${loot}.` : `${m.name} cai. +${m.gold} ouro. O depósito não coube o saque.`);
  mark(`+${m.gold} ouro`, { text: `+${m.gold}`, k: "loot" });
  if (!save.autoCombat) {
    save.action = null;
    notify(`Vitória. +${m.gold} ouro`);
  }
  if (m.name.startsWith("Chefe")) notify(`${m.name} derrotado`);
}

const eatOrder = Object.entries(foods)
  .map(([id, heal]) => ({ id, heal }))
  .sort((a, b) => a.heal - b.heal);

function eatSmart() {
  if (!save.autoFood) return;
  const ratio = save.hp / Math.max(1, save.maxhp);
  if (ratio >= 0.62) return;
  const have = eatOrder.filter((f) => inv(f.id) > 0);
  if (!have.length) return;
  const missing = save.maxhp - save.hp;
  const pick = ratio < 0.32 ? have[have.length - 1] : have.find((f) => f.heal >= missing * 0.65) || have[0];
  add(pick.id, -1);
  const before = save.hp;
  save.hp = Math.min(save.maxhp, save.hp + pick.heal);
  const gained = save.hp - before;
  note("eat", `Você usa ${items[pick.id]?.name || pick.id} e recupera ${gained}.`);
}

function combatTurn(zone: number, index: number) {
  const m = zones[zone]?.monsters[index];
  if (!m) return;
  const p = playerStats();
  save.maxhp = p.max;
  save.hp = Math.min(save.hp, save.maxhp);
  if (!save.battle) save.battle = { hp: m.hp, guard: false };
  const b = save.battle;
  if (b.hp <= 0) {
    win(zone, index);
    return;
  }
  let dmg = Math.max(1, Math.round(p.atk * (0.75 + Math.random() * 0.45)));
  if (save.style === "magic") {
    dmg = Math.round(dmg * 0.5 + p.magic * 1.6);
    gain("magic", m.level + 4);
  } else if (save.style === "ranged") {
    dmg = Math.round(dmg * 0.9);
    gain("ranged", m.level + 4);
  } else gain("attack", m.level + 4);
  b.hp -= dmg;
  gain("strength", Math.ceil(m.level / 2));
  const verb = save.style === "magic" ? "O feitiço acerta" : save.style === "ranged" ? "A flecha acerta" : "Você acerta";
  note("hit", `${verb} ${m.name} e tira ${dmg}.`);
  mark(`−${dmg}`, { text: `−${dmg}`, k: "foe" });
  if (b.hp <= 0) {
    win(zone, index);
    return;
  }
  let incoming = Math.max(1, Math.round(m.atk * (0.7 + Math.random() * 0.6) - p.def * 0.42));
  if (activeBonus() === "def") incoming = Math.ceil(incoming * 0.92);
  save.hp = Math.max(0, save.hp - incoming);
  gain("defense", Math.ceil(m.level / 3));
  note("hurt", `${m.name} devolve ${incoming}.`);
  save.turn += 1;
  eatSmart();
  if (save.hp <= 0) {
    save.hp = save.maxhp;
    save.gold = Math.max(0, save.gold - Math.ceil(save.gold * 0.04));
    save.battle = null;
    save.action = null;
    note("lose", "Você cai. A trilha toma 4% do ouro.");
    notify("Derrota. Você perdeu 4% do ouro.");
  }
}

function fullStop(msg: string) {
  save.action = null;
  save.progress = 0;
  notify(msg);
}

function tickAction() {
  const a = save.action;
  if (!a) return;
  save.stats.actions += 1;
  save.contractCounts.actions = (save.contractCounts.actions || 0) + 1;
  if (a.type === "skill") {
    const row = listFor(a.skill)?.[a.index];
    if (!row || lvl(a.skill) < row.level) {
      save.action = null;
      save.progress = 0;
      return;
    }
    if (nodes[a.skill]) {
      if (!add(row.item)) return fullStop("O depósito encheu. A coleta parou.");
      gain(a.skill, row.xp);
      let extra = "";
      if (Math.random() < 0.012 && add("gem")) extra += " · gema";
      if (a.skill === "mining" && Math.random() < 0.05 && add("crystal")) extra += " · cristal";
      mark(`+1 ${items[row.item]?.name || row.item}${extra}`, { text: "+1", k: "loot" });
    } else {
      const recipe = recipes[a.skill]?.[a.index];
      if (!recipe || !spend(recipe.cost)) {
        save.action = null;
        save.progress = 0;
        notify("Faltam materiais.");
        return;
      }
      if (!add(recipe.item)) {
        Object.entries(recipe.cost).forEach(([k, v]) => add(k, v));
        return fullStop("O depósito encheu. O ofício parou.");
      }
      gain(a.skill, recipe.xp);
      save.stats.crafted += 1;
      mark(`+1 ${items[recipe.item]?.name || recipe.item}`, { text: "+1", k: "loot" });
    }
  } else combatTurn(a.zone, a.index);
}

export function workerPlan(w: Worker) {
  const job = workerJobs[w.job] || workerJobs.mining;
  const open = job.tiers.map((tier, index) => ({ tier, index })).filter(({ tier }) => lvl(job.xp) >= tier.level);
  const pool = open.length ? open : [{ tier: job.tiers[0], index: 0 }];
  const pinned = w.tier != null && w.tier >= 0 ? pool.find((x) => x.index === w.tier) : undefined;
  const chosen = pinned || pool[pool.length - 1];
  return { job, tier: chosen.tier, index: chosen.index };
}

function workerTick(sec: number) {
  if (!save.workers.length) return;
  save.workerClock = (save.workerClock || 0) + sec;
  for (const w of save.workers) {
    if (!w.active) continue;
    const plan = workerPlan(w);
    const tier = plan.tier;
    w.progress = (w.progress || 0) + sec;
    while (w.progress >= tier.interval) {
      if (tier.cost && !spend(tier.cost)) {
        w.active = false;
        notify(`${w.name} pausou: faltam materiais para ${tier.name.toLowerCase()}.`);
        break;
      }
      const wage = 1 + Math.floor((w.level - 1) / 3);
      if (save.gold < wage) {
        if (tier.cost) Object.entries(tier.cost).forEach(([k, v]) => add(k, v));
        w.active = false;
        notify(`${w.name} parou: falta ouro para o salário.`);
        break;
      }
      const amount =
        tier.base +
        Math.floor((w.level - 1) / 4) +
        (activeBonus() === "gather" ? 1 : 0) +
        (save.property.workshop > 0 && (w.job === "smithing" || w.job === "cooking") ? 1 : 0);
      w.progress -= tier.interval;
      save.gold -= wage;
      if (!add(tier.resource, amount)) {
        save.gold += wage;
        if (tier.cost) Object.entries(tier.cost).forEach(([k, v]) => add(k, v));
        w.active = false;
        notify(`${w.name} parou: o depósito está cheio.`);
        break;
      }
      gain(plan.job.xp, tier.xp + Math.floor(w.level / 2));
      w.xp = (w.xp || 0) + 5;
      const old = w.level;
      w.level = Math.min(30, Math.floor(Math.sqrt(w.xp / 45)) + 1);
      if (w.level > old) notify(`${w.name} evoluiu para o nível ${w.level}`);
      save.stats.workerActions = (save.stats.workerActions || 0) + 1;
      save.stats.actions += 1;
      save.contractCounts.workers = (save.contractCounts.workers || 0) + 1;
    }
  }
}

function gardenTick(sec: number) {
  const lv = save.property.garden || 0;
  if (lv <= 0) return;
  save.gardenClock = (save.gardenClock || 0) + sec;
  while (save.gardenClock >= 40) {
    save.gardenClock -= 40;
    add("food", lv);
  }
}

export function step(sec: number, offline = false) {
  workerTick(sec);
  gardenTick(sec);
  const a = save.action;
  if (!a) return;
  const row = a.type === "skill" ? listFor(a.skill)?.[a.index] : null;
  const speed = a.type === "combat" ? 2.4 : row?.seconds || 3;
  const bonus = a.type === "skill" ? speedMult(a.skill) : 1;
  save.progress += sec / (speed * bonus);
  const loops = Math.min(Math.floor(save.progress), offline ? 25000 : 5);
  save.progress -= loops;
  for (let i = 0; i < loops; i += 1) {
    if (!save.action) break;
    tickAction();
  }
}

let uiClock = 0;
export function frame(dt: number) {
  step(dt, false);
  const p = playerStats();
  save.maxhp = p.max;
  save.hp = Math.min(save.hp, save.maxhp);
  uiClock += dt;
  if (uiClock > 0.2) {
    uiClock = 0;
    emit();
  }
}

function normalize(raw: Partial<Save> | null): Save {
  const base = initial();
  if (!raw || typeof raw !== "object") return base;
  const next: Save = {
    ...base,
    ...raw,
    levels: { ...base.levels, ...(raw.levels || {}) },
    inventory: { ...(raw.inventory || {}) },
    equip: { ...base.equip, ...(raw.equip || {}) },
    workers: Array.isArray(raw.workers) ? raw.workers : [],
    stats: { ...base.stats, ...(raw.stats || {}) },
    property: { ...base.property, ...(raw.property || {}) },
    pets: Array.isArray(raw.pets) ? raw.pets : [],
    contractCounts: { ...base.contractCounts, ...(raw.contractCounts || {}) },
    contractClaimed: Array.isArray(raw.contractClaimed) ? raw.contractClaimed : [],
    dailyContracts: Array.isArray(raw.dailyContracts) ? raw.dailyContracts : [],
    unlocked: Array.isArray(raw.unlocked) && raw.unlocked.length ? raw.unlocked : [0],
    gardenClock: raw.gardenClock || 0,
    log: cleanLog(raw.log),
  };
  return next;
}

function cleanLog(raw: unknown): LogLine[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((x): x is LogLine => !!x && typeof x === "object" && typeof (x as LogLine).text === "string" && typeof (x as LogLine).k === "string")
    .slice(0, 14);
}

export function ensureContracts() {
  const day = new Date().toISOString().slice(0, 10);
  if (save.contractDay === day && save.dailyContracts?.length) return;
  save.contractDay = day;
  save.contractCounts = { kills: 0, actions: 0, workers: 0 };
  save.contractClaimed = [];
  let list = [
    contractPool[day.charCodeAt(8) % contractPool.length],
    contractPool[(day.charCodeAt(9) + 2) % contractPool.length],
    contractPool[(day.charCodeAt(7) + 4) % contractPool.length],
  ].filter((q, i, a) => a.findIndex((x) => x.id === q.id) === i);
  if (list.length < 3) {
    list = [...list, ...contractPool.filter((q) => !list.some((x) => x.id === q.id))].slice(0, 3);
  }
  save.dailyContracts = list;
}

function awayCap() {
  return (8 + (activeBonus() === "offline" ? 2 : 0)) * 3600;
}

function applyAway(announce: boolean) {
  const elapsed = Math.max(0, Math.min(awayCap(), (Date.now() - (save.last || Date.now())) / 1000));
  if (elapsed > 5 && (save.action || save.workers.length || save.property.garden > 0)) {
    const old = save.stats.actions;
    quiet = true;
    step(elapsed, true);
    quiet = false;
    const done = save.stats.actions - old;
    if (announce && done > 0) window.setTimeout(() => notify(`Progresso offline: ${num(done)} ações`), 400);
  }
}

export function catchUp() {
  applyAway(true);
  saveNow();
  emit();
}

export function boot() {
  if (booted) return;
  booted = true;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    save = normalize(raw ? (JSON.parse(raw) as Partial<Save>) : null);
  } catch {
    save = initial();
  }
  ensureContracts();
  applyAway(true);
  const p = playerStats();
  save.maxhp = p.max;
  if (save.stats.actions === 0 && save.kills === 0) save.hp = p.max;
  else save.hp = Math.min(save.hp || p.max, p.max);
  saveNow();
  emit();
}

export function setTab(tab: Tab) {
  ui.tab = tab;
  ui.confirmReset = false;
  if (tab === "contracts") ensureContracts();
  emit();
}
export function openSkill(id: SkillId) {
  ui.selected = id;
  ui.tab = "detail";
  emit();
}
export function toggleAuto(key: "autoFood" | "autoCombat") {
  save[key] = !save[key];
  commit();
}
export function setStyle(style: Save["style"]) {
  save.style = style;
  commit();
}
export function unlockZone(z: number) {
  if (save.gold < zones[z].cost) return notify("Ouro insuficiente.");
  if (z > 0 && !save.unlocked.includes(z - 1)) return notify("Desbloqueie a região anterior.");
  save.gold -= zones[z].cost;
  save.unlocked.push(z);
  commit();
}
export function equipItem(id: string) {
  const stat = gearStats[id];
  if (!stat || !inv(id)) return;
  save.equip[stat.slot] = save.equip[stat.slot] === id ? null : id;
  commit();
}
export function useItem(id: string) {
  const heal = foods[id];
  if (!heal || !inv(id)) return;
  add(id, -1);
  const before = save.hp;
  save.hp = Math.min(save.maxhp, save.hp + heal);
  notify(`+${save.hp - before} HP`);
  commit();
}
export function hireWorker(job: JobId) {
  const count = save.workers.length;
  if (count >= 6) return notify("Sua propriedade comporta no máximo 6 servos.");
  const cost = hireCosts[Math.min(count, hireCosts.length - 1)];
  if (save.gold < cost) return notify(`Você precisa de ${cost} ouro para contratar.`);
  save.gold -= cost;
  const name = workerNames.find((n) => !save.workers.some((w) => w.name === n)) || `Servo ${count + 1}`;
  save.workers.push({ id: Date.now() + Math.floor(Math.random() * 1000), name, job, level: 1, xp: 0, progress: 0, active: true });
  notify(`${name} foi contratado`);
  commit();
}
export function setWorkerJob(id: number, job: JobId) {
  const w = save.workers.find((x) => x.id === id);
  if (!w || !workerJobs[job]) return;
  w.job = job;
  w.tier = -1;
  w.progress = 0;
  commit();
}
export function setWorkerTier(id: number, tier: number) {
  const w = save.workers.find((x) => x.id === id);
  if (!w) return;
  w.tier = tier;
  w.progress = 0;
  commit();
}
export function toggleWorker(id: number) {
  const w = save.workers.find((x) => x.id === id);
  if (!w) return;
  w.active = !w.active;
  commit();
}
export function build(id: PropertyId) {
  const def = propertyDefs[id];
  const lv = save.property[id] || 0;
  if (lv >= def.max) return notify("Esta construção já atingiu o nível máximo.");
  const cost: Record<string, number> = {};
  Object.entries(def.cost).forEach(([k, n]) => {
    cost[k] = n * (lv + 1);
  });
  if (!spend(cost)) return notify(`Materiais insuficientes: ${costText(cost)}`);
  save.property[id] = lv + 1;
  notify(`${def.name} aprimorada para o nível ${lv + 1}`);
  commit();
}
export function marketTrade(stallId: StallId, id: string, qty: number, mode: "buy" | "sell") {
  const stall = stalls[stallId];
  const item = stall?.goods.find((x) => x.id === id);
  if (!stall || !item) return;
  qty = Math.max(1, Math.min(99, Math.floor(Number(qty) || 1)));
  const price = item.price * qty;
  if (mode === "buy") {
    if (save.gold < price) return notify("Ouro insuficiente.");
    if (usedStorage() + qty > storageCapacity()) return notify("Seu depósito está cheio.");
    save.gold -= price;
    add(id, qty);
    notify(`Comprou ${qty}× ${items[id]?.name || id}`);
  } else {
    if (inv(id) < qty) return notify("Você não possui essa quantidade.");
    add(id, -qty);
    const earned = Math.floor(price * stall.sell);
    save.gold += earned;
    notify(`Vendeu ${qty}× ${items[id]?.name || id} por ${earned} ouro`);
  }
  commit();
}
export function adoptPet(id: string) {
  const p = petDefs.find((x) => x.id === id);
  if (!p || save.pets.some((x) => x.id === id)) return notify("Você já possui esse mascote.");
  if (save.gold < p.cost) return notify("Ouro insuficiente para adotar esse mascote.");
  save.gold -= p.cost;
  save.pets.push({ ...p });
  if (!save.activePet) save.activePet = id;
  notify(`${p.name} agora é seu companheiro`);
  commit();
}
export function setPet(id: string) {
  save.activePet = save.activePet === id ? null : id;
  commit();
}
export function claimContract(id: string) {
  const q = (save.dailyContracts || []).find((x) => x.id === id);
  if (!q || save.contractClaimed.includes(id)) return;
  if ((save.contractCounts[q.type] || 0) < q.goal) return notify("Contrato ainda não concluído.");
  save.contractClaimed.push(id);
  save.gold += q.gold;
  gain("attack", q.xp);
  add("gem", 1);
  notify(`Contrato concluído. +${q.gold} ouro e uma gema`);
  commit();
}
export function exportCode() {
  return btoa(unescape(encodeURIComponent(JSON.stringify(save))));
}
export function importCode(raw: string) {
  try {
    const data = JSON.parse(decodeURIComponent(escape(atob(raw.trim())))) as Partial<Save>;
    if (!data.levels || !data.inventory) throw new Error("bad");
    save = normalize(data);
    ensureContracts();
    commit();
    notify("Save importado");
  } catch {
    notify("Código inválido.");
  }
}
export function askReset() {
  ui.confirmReset = true;
  emit();
}
export function cancelReset() {
  ui.confirmReset = false;
  emit();
}
export function resetGame() {
  localStorage.removeItem(SAVE_KEY);
  save = initial();
  ensureContracts();
  ui.confirmReset = false;
  ui.tab = "home";
  commit();
}

export function actionLabel() {
  const a = save.action;
  if (!a) return { title: "Nenhuma atividade", detail: "Escolha uma perícia ou uma expedição.", kind: "Descanso" };
  if (a.type === "combat") {
    const m = zones[a.zone]?.monsters[a.index];
    return { title: m?.name || "Combate", detail: "Confronto em andamento.", kind: "Combate" };
  }
  const row = listFor(a.skill)?.[a.index];
  const skill = skills.find((s) => s.id === a.skill);
  return { title: row?.name || skill?.name || "Perícia", detail: "A produção continua ao navegar.", kind: skill?.name || "Perícia" };
}
