export type SkillId =
  | "attack"
  | "strength"
  | "defense"
  | "ranged"
  | "magic"
  | "wood"
  | "mining"
  | "fishing"
  | "cooking"
  | "smithing"
  | "alchemy"
  | "craft";

export type SkillGroup = "Combate" | "Coleta" | "Produção";

export type Skill = { id: SkillId; name: string; group: SkillGroup };
export type NodeDef = { name: string; level: number; seconds: number; xp: number; item: string };
export type RecipeDef = NodeDef & { cost: Record<string, number> };
export type Monster = { name: string; level: number; hp: number; atk: number; gold: number; loot: string };
export type Zone = { name: string; level: number; cost: number; monsters: Monster[] };
export type ItemDef = { name: string; kind: "material" | "gear" | "food" };

export const SAVE_KEY = "ashes_idle_v03";

export const skills: Skill[] = [
  { id: "attack", name: "Ataque", group: "Combate" },
  { id: "strength", name: "Força", group: "Combate" },
  { id: "defense", name: "Defesa", group: "Combate" },
  { id: "ranged", name: "Distância", group: "Combate" },
  { id: "magic", name: "Magia", group: "Combate" },
  { id: "wood", name: "Lenha", group: "Coleta" },
  { id: "mining", name: "Mineração", group: "Coleta" },
  { id: "fishing", name: "Pesca", group: "Coleta" },
  { id: "cooking", name: "Culinária", group: "Produção" },
  { id: "smithing", name: "Metalurgia", group: "Produção" },
  { id: "alchemy", name: "Alquimia", group: "Produção" },
  { id: "craft", name: "Artesanato", group: "Produção" },
];

export const nodes: Partial<Record<SkillId, NodeDef[]>> = {
  mining: [
    { name: "Veio de Cobre", level: 1, seconds: 1.8, xp: 8, item: "oreCopper" },
    { name: "Veio de Ferro", level: 8, seconds: 3.2, xp: 23, item: "oreIron" },
    { name: "Veio de Prata", level: 18, seconds: 4.8, xp: 49, item: "oreSilver" },
    { name: "Veio de Cristal", level: 35, seconds: 6.5, xp: 110, item: "crystal" },
    { name: "Veio de Cinzálio", level: 55, seconds: 9, xp: 230, item: "oreAsh" },
  ],
  wood: [
    { name: "Árvore Retorcida", level: 1, seconds: 2, xp: 8, item: "wood" },
    { name: "Bétula Pálida", level: 12, seconds: 3.5, xp: 27, item: "birch" },
    { name: "Madeira Sombria", level: 30, seconds: 5.5, xp: 75, item: "darkwood" },
    { name: "Árvore Ancestral", level: 55, seconds: 8, xp: 185, item: "elderwood" },
  ],
  fishing: [
    { name: "Peixe do Riacho", level: 1, seconds: 2.4, xp: 9, item: "fish" },
    { name: "Truta das Cinzas", level: 12, seconds: 3.5, xp: 30, item: "trout" },
    { name: "Enguia Espectral", level: 30, seconds: 5.5, xp: 84, item: "eel" },
    { name: "Peixe Abissal", level: 55, seconds: 8, xp: 210, item: "abyssfish" },
  ],
};

export const recipes: Partial<Record<SkillId, RecipeDef[]>> = {
  cooking: [
    { name: "Peixe Assado", level: 1, seconds: 3, xp: 15, cost: { fish: 2 }, item: "food" },
    { name: "Truta Defumada", level: 12, seconds: 4, xp: 38, cost: { trout: 2, wood: 1 }, item: "foodBig" },
    { name: "Ensopado de Enguia", level: 30, seconds: 5, xp: 90, cost: { eel: 2, birch: 1 }, item: "foodEel" },
    { name: "Banquete Abissal", level: 55, seconds: 7, xp: 210, cost: { abyssfish: 2, darkwood: 1 }, item: "foodAbyss" },
  ],
  smithing: [
    { name: "Barra de Cobre", level: 1, seconds: 4, xp: 18, cost: { oreCopper: 3 }, item: "barCopper" },
    { name: "Espada de Cobre", level: 3, seconds: 7, xp: 38, cost: { barCopper: 4, wood: 2 }, item: "swordCopper" },
    { name: "Picareta de Cobre", level: 4, seconds: 7, xp: 40, cost: { barCopper: 3, wood: 2 }, item: "pickCopper" },
    { name: "Barra de Ferro", level: 8, seconds: 5, xp: 38, cost: { oreIron: 3 }, item: "barIron" },
    { name: "Picareta de Ferro", level: 10, seconds: 8, xp: 55, cost: { barIron: 3, wood: 2 }, item: "pickIron" },
    { name: "Espada de Ferro", level: 12, seconds: 10, xp: 75, cost: { barIron: 5, wood: 3 }, item: "swordIron" },
    { name: "Armadura de Ferro", level: 16, seconds: 12, xp: 90, cost: { barIron: 8 }, item: "armorIron" },
    { name: "Barra de Prata", level: 18, seconds: 6, xp: 70, cost: { oreSilver: 3 }, item: "barSilver" },
    { name: "Lâmina de Prata", level: 24, seconds: 11, xp: 120, cost: { barSilver: 5, birch: 2 }, item: "swordSilver" },
    { name: "Picareta de Prata", level: 28, seconds: 11, xp: 130, cost: { barSilver: 4, birch: 2 }, item: "pickSilver" },
    { name: "Cota de Prata", level: 32, seconds: 13, xp: 150, cost: { barSilver: 8 }, item: "armorSilver" },
    { name: "Lâmina de Cinzálio", level: 55, seconds: 16, xp: 260, cost: { oreAsh: 12, crystal: 5 }, item: "swordAsh" },
    { name: "Placas de Cinzálio", level: 62, seconds: 18, xp: 300, cost: { oreAsh: 10, barSilver: 4 }, item: "armorAsh" },
  ],
  alchemy: [
    { name: "Poção de Vida", level: 1, seconds: 5, xp: 25, cost: { wood: 2, oreCopper: 1 }, item: "potion" },
    { name: "Elixir Arcano", level: 15, seconds: 7, xp: 48, cost: { crystal: 2, oreSilver: 1 }, item: "elixir" },
    { name: "Tônico de Enguia", level: 32, seconds: 8, xp: 110, cost: { eel: 1, crystal: 1 }, item: "tonic" },
    { name: "Frasco do Abismo", level: 55, seconds: 10, xp: 230, cost: { abyssfish: 1, oreAsh: 1, crystal: 1 }, item: "vial" },
  ],
  craft: [
    { name: "Arco Simples", level: 1, seconds: 5, xp: 25, cost: { wood: 5 }, item: "bow" },
    { name: "Arco de Bétula", level: 14, seconds: 7, xp: 55, cost: { birch: 6, wood: 2 }, item: "bowBirch" },
    { name: "Capa Sombria", level: 20, seconds: 8, xp: 60, cost: { darkwood: 5, birch: 3 }, item: "cape" },
    { name: "Couraça Ancestral", level: 40, seconds: 12, xp: 160, cost: { elderwood: 8, birch: 4 }, item: "armorElder" },
    { name: "Arco Ancestral", level: 48, seconds: 12, xp: 190, cost: { elderwood: 6, darkwood: 2, crystal: 1 }, item: "bowElder" },
    { name: "Manto Ancestral", level: 52, seconds: 12, xp: 200, cost: { elderwood: 5, darkwood: 4, gem: 1 }, item: "capeElder" },
  ],
};

const mat = (name: string): ItemDef => ({ name, kind: "material" });
const gear = (name: string): ItemDef => ({ name, kind: "gear" });
const food = (name: string): ItemDef => ({ name, kind: "food" });

export const items: Record<string, ItemDef> = {
  oreCopper: mat("Minério de Cobre"),
  oreIron: mat("Minério de Ferro"),
  oreSilver: mat("Minério de Prata"),
  crystal: mat("Cristal Arcano"),
  oreAsh: mat("Cinzálio"),
  wood: mat("Madeira Retorcida"),
  birch: mat("Bétula Pálida"),
  darkwood: mat("Madeira Sombria"),
  elderwood: mat("Madeira Ancestral"),
  fish: mat("Peixe do Riacho"),
  trout: mat("Truta"),
  eel: mat("Enguia"),
  abyssfish: mat("Peixe Abissal"),
  food: food("Peixe Assado"),
  foodBig: food("Truta Defumada"),
  foodEel: food("Ensopado de Enguia"),
  foodAbyss: food("Banquete Abissal"),
  barCopper: mat("Barra de Cobre"),
  barIron: mat("Barra de Ferro"),
  barSilver: mat("Barra de Prata"),
  swordCopper: gear("Espada de Cobre"),
  swordIron: gear("Espada de Ferro"),
  swordSilver: gear("Lâmina de Prata"),
  swordAsh: gear("Lâmina de Cinzálio"),
  pickCopper: gear("Picareta de Cobre"),
  pickIron: gear("Picareta de Ferro"),
  pickSilver: gear("Picareta de Prata"),
  armorIron: gear("Armadura de Ferro"),
  armorSilver: gear("Cota de Prata"),
  armorElder: gear("Couraça Ancestral"),
  armorAsh: gear("Placas de Cinzálio"),
  potion: food("Poção de Vida"),
  elixir: food("Elixir Arcano"),
  tonic: food("Tônico de Enguia"),
  vial: food("Frasco do Abismo"),
  bow: gear("Arco Simples"),
  bowBirch: gear("Arco de Bétula"),
  bowElder: gear("Arco Ancestral"),
  cape: gear("Capa Sombria"),
  capeElder: gear("Manto Ancestral"),
  bone: mat("Osso Antigo"),
  fang: mat("Presa"),
  ash: mat("Essência de Cinzas"),
  gem: mat("Gema Rara"),
  bogEssence: mat("Essência do Pântano"),
  venom: mat("Veneno Concentrado"),
  duskShard: mat("Fragmento Crepuscular"),
  voidCore: mat("Núcleo do Vazio"),
};

export type GearSlot = "weapon" | "armor" | "tool" | "accessory";
export type GearStat = { slot: GearSlot; atk?: number; def?: number; mag?: number; mine?: number; label: string };

export const gearStats: Record<string, GearStat> = {
  swordCopper: { slot: "weapon", atk: 15, label: "+15 de ataque" },
  bow: { slot: "weapon", atk: 12, label: "+12 de ataque" },
  swordIron: { slot: "weapon", atk: 32, label: "+32 de ataque" },
  bowBirch: { slot: "weapon", atk: 26, label: "+26 de ataque" },
  swordSilver: { slot: "weapon", atk: 55, label: "+55 de ataque" },
  bowElder: { slot: "weapon", atk: 72, label: "+72 de ataque" },
  swordAsh: { slot: "weapon", atk: 100, label: "+100 de ataque" },
  armorIron: { slot: "armor", def: 28, label: "+28 de defesa" },
  armorSilver: { slot: "armor", def: 46, label: "+46 de defesa" },
  armorElder: { slot: "armor", def: 52, label: "+52 de defesa" },
  armorAsh: { slot: "armor", def: 84, label: "+84 de defesa" },
  pickCopper: { slot: "tool", mine: 0.8, label: "Mineração 20% mais rápida" },
  pickIron: { slot: "tool", mine: 0.68, label: "Mineração 32% mais rápida" },
  pickSilver: { slot: "tool", mine: 0.55, label: "Mineração 45% mais rápida" },
  cape: { slot: "accessory", def: 6, label: "+6 de defesa" },
  capeElder: { slot: "accessory", def: 14, mag: 18, label: "+14 de defesa e +18 de magia" },
};

export const foods: Record<string, number> = {
  food: 35,
  foodBig: 80,
  potion: 90,
  foodEel: 150,
  elixir: 180,
  tonic: 240,
  foodAbyss: 280,
  vial: 360,
};

export function itemBlurb(id: string) {
  if (foods[id]) return `Recupera ${foods[id]} de vida.`;
  return gearStats[id]?.label || "";
}

export const zones: Zone[] = [
  {
    name: "Campos das Brasas",
    level: 1,
    cost: 0,
    monsters: [
      { name: "Rato Corrompido", level: 1, hp: 35, atk: 7, gold: 12, loot: "fang" },
      { name: "Bandido Desgarrado", level: 4, hp: 60, atk: 11, gold: 21, loot: "bone" },
      { name: "Lobo Cinzento", level: 8, hp: 100, atk: 16, gold: 32, loot: "fang" },
      { name: "Chefe: Saqueador", level: 12, hp: 220, atk: 23, gold: 75, loot: "gem" },
    ],
  },
  {
    name: "Floresta dos Lamentos",
    level: 14,
    cost: 400,
    monsters: [
      { name: "Aranha de Névoa", level: 14, hp: 160, atk: 22, gold: 45, loot: "fang" },
      { name: "Guardião de Musgo", level: 20, hp: 250, atk: 28, gold: 65, loot: "wood" },
      { name: "Espectro Faminto", level: 27, hp: 360, atk: 36, gold: 92, loot: "ash" },
      { name: "Chefe: Rei dos Espinhos", level: 35, hp: 650, atk: 49, gold: 180, loot: "gem" },
    ],
  },
  {
    name: "Cripta do Eclipse",
    level: 35,
    cost: 3000,
    monsters: [
      { name: "Esqueleto Guerreiro", level: 35, hp: 500, atk: 49, gold: 125, loot: "bone" },
      { name: "Cavaleiro Esquecido", level: 43, hp: 720, atk: 65, gold: 180, loot: "barIron" },
      { name: "Bruxa das Cinzas", level: 52, hp: 940, atk: 82, gold: 260, loot: "crystal" },
      { name: "Chefe: Vigia do Eclipse", level: 62, hp: 1600, atk: 112, gold: 600, loot: "gem" },
    ],
  },
  {
    name: "Abismo Carmesim",
    level: 65,
    cost: 18000,
    monsters: [
      { name: "Demônio das Brasas", level: 65, hp: 1450, atk: 120, gold: 390, loot: "ash" },
      { name: "Draco Vulcânico", level: 75, hp: 2400, atk: 170, gold: 700, loot: "gem" },
      { name: "Chefe: Coração da Ruína", level: 90, hp: 4500, atk: 230, gold: 1600, loot: "gem" },
    ],
  },
  {
    name: "Pântano dos Ecos",
    level: 95,
    cost: 42000,
    monsters: [
      { name: "Lodo Devorador", level: 95, hp: 5200, atk: 245, gold: 1900, loot: "bogEssence" },
      { name: "Caçador Afogado", level: 102, hp: 6800, atk: 285, gold: 2300, loot: "bogEssence" },
      { name: "Serpente Venenosa", level: 110, hp: 8200, atk: 320, gold: 2800, loot: "venom" },
      { name: "Chefe: Mãe do Lodo", level: 120, hp: 15000, atk: 390, gold: 6500, loot: "bogEssence" },
    ],
  },
  {
    name: "Cidadela do Crepúsculo",
    level: 125,
    cost: 95000,
    monsters: [
      { name: "Sentinela Crepuscular", level: 125, hp: 16000, atk: 420, gold: 4200, loot: "duskShard" },
      { name: "Lâmina Espectral", level: 135, hp: 19000, atk: 465, gold: 5000, loot: "duskShard" },
      { name: "Arauto do Vazio", level: 145, hp: 24000, atk: 520, gold: 6200, loot: "voidCore" },
      { name: "Chefe: Regente Sem Sol", level: 160, hp: 42000, atk: 650, gold: 15000, loot: "voidCore" },
    ],
  },
];

export type StallId = "pedro" | "luan";

export const stalls: Record<
  StallId,
  { name: string; role: string; sell: number; line: string; goods: { id: string; price: number }[] }
> = {
  pedro: {
    name: "Pedro",
    role: "Suprimentos de expedição",
    sell: 0.62,
    line: "O que a trilha ainda deixa passar, eu tenho. Ouro na mesa, mercadoria na mochila.",
    goods: [
      { id: "oreCopper", price: 4 },
      { id: "oreIron", price: 14 },
      { id: "oreSilver", price: 22 },
      { id: "wood", price: 3 },
      { id: "birch", price: 9 },
      { id: "darkwood", price: 28 },
      { id: "elderwood", price: 70 },
      { id: "fish", price: 5 },
      { id: "trout", price: 16 },
      { id: "eel", price: 26 },
      { id: "abyssfish", price: 80 },
      { id: "food", price: 9 },
      { id: "bone", price: 8 },
      { id: "fang", price: 8 },
    ],
  },
  luan: {
    name: "Luan",
    role: "Bancada do artesão",
    sell: 0.74,
    line: "Barras, frascos e o que brilha. Eu pago melhor pelo que você mesmo faz.",
    goods: [
      { id: "barCopper", price: 18 },
      { id: "barIron", price: 42 },
      { id: "barSilver", price: 78 },
      { id: "potion", price: 22 },
      { id: "elixir", price: 70 },
      { id: "tonic", price: 95 },
      { id: "vial", price: 160 },
      { id: "foodBig", price: 24 },
      { id: "foodEel", price: 48 },
      { id: "foodAbyss", price: 110 },
      { id: "crystal", price: 55 },
      { id: "gem", price: 35 },
      { id: "oreAsh", price: 90 },
      { id: "bogEssence", price: 85 },
      { id: "venom", price: 65 },
      { id: "duskShard", price: 140 },
      { id: "voidCore", price: 320 },
    ],
  },
};

const skillIcons: Record<SkillId, string> = {
  attack: "sword",
  strength: "axe",
  defense: "shield",
  ranged: "bow",
  magic: "orb",
  wood: "axe",
  mining: "pick",
  fishing: "rod",
  cooking: "pot",
  smithing: "anvil",
  alchemy: "flask",
  craft: "thread",
};

export function skillIcon(id: SkillId) {
  return `/pixel/ico-${skillIcons[id]}.png`;
}

export function itemIcon(id: string) {
  if (id === "gold") return "/pixel/ico-coins.png";
  if (items[id]) return `/pixel/items/${id}.png`;
  return "/pixel/ico-ore.png";
}

export function monsterSrc(name: string) {
  const n = name.toLowerCase();
  if (n.includes("aranha")) return "/pixel/mon-spider.png";
  if (n.includes("lobo")) return "/pixel/mon-wolf.png";
  if (n.includes("rato")) return "/pixel/mon-rat.png";
  if (n.includes("lodo") || n.includes("serpente") || n.includes("mãe") || n.includes("afogado")) return "/pixel/mon-slime.png";
  if (n.includes("draco") || n.includes("demônio") || n.includes("coração")) return "/pixel/mon-drake.png";
  if (
    n.includes("espectro") ||
    n.includes("bruxa") ||
    n.includes("vazio") ||
    n.includes("regente") ||
    n.includes("vigia") ||
    n.includes("araute") ||
    n.includes("lâmina") ||
    n.includes("crepusc")
  )
    return "/pixel/mon-wraith.png";
  return "/pixel/mon-skeleton.png";
}

export function sceneForSkill(id: SkillId) {
  const map: Partial<Record<SkillId, string>> = {
    mining: "/pixel/scene-mine.jpg",
    wood: "/pixel/scene-wood.jpg",
    fishing: "/pixel/scene-fish.jpg",
    smithing: "/pixel/scene-forge.jpg",
    cooking: "/pixel/scene-hearth.jpg",
    alchemy: "/pixel/scene-lab.jpg",
    craft: "/pixel/scene-home.jpg",
  };
  return map[id] || "/pixel/scene-combat.jpg";
}

export function heroPose(id?: SkillId, combat = false) {
  if (combat) return "/pixel/hero-fight.png";
  const map: Partial<Record<SkillId, string>> = {
    mining: "/pixel/hero-mine.png",
    wood: "/pixel/hero-wood.png",
    fishing: "/pixel/hero-fish.png",
    smithing: "/pixel/hero-forge.png",
    cooking: "/pixel/hero-cook.png",
    alchemy: "/pixel/hero-flask.png",
    craft: "/pixel/hero-forge.png",
    attack: "/pixel/hero-fight.png",
    strength: "/pixel/hero-fight.png",
    defense: "/pixel/hero-fight.png",
    ranged: "/pixel/hero-fight.png",
    magic: "/pixel/hero-flask.png",
  };
  return (id && map[id]) || "/pixel/hero-idle.png";
}

export const zoneScenes = [
  "/pixel/scene-combat.jpg",
  "/pixel/scene-wood.jpg",
  "/pixel/scene-crypt.jpg",
  "/pixel/scene-abyss.jpg",
  "/pixel/scene-swamp.jpg",
  "/pixel/scene-citadel.jpg",
];

export const petArt: Record<string, string> = {
  mossling: "/pixel/pet-moss.png",
  emberfox: "/pixel/pet-fox.png",
  stonecub: "/pixel/pet-cub.png",
  nightowl: "/pixel/pet-owl.png",
};


export type WorkerTier = {
  name: string;
  level: number;
  resource: string;
  interval: number;
  base: number;
  xp: number;
  cost?: Record<string, number>;
};

export const workerJobs: Record<"mining" | "wood" | "fishing" | "smithing" | "cooking", { name: string; xp: SkillId; tiers: WorkerTier[] }> = {
  mining: {
    name: "Mineração",
    xp: "mining",
    tiers: [
      { name: "Cobre", level: 1, resource: "oreCopper", interval: 9, base: 1, xp: 4 },
      { name: "Ferro", level: 8, resource: "oreIron", interval: 12, base: 1, xp: 8 },
      { name: "Prata", level: 18, resource: "oreSilver", interval: 16, base: 1, xp: 14 },
      { name: "Cristal", level: 35, resource: "crystal", interval: 22, base: 1, xp: 22 },
      { name: "Cinzálio", level: 55, resource: "oreAsh", interval: 28, base: 1, xp: 36 },
    ],
  },
  wood: {
    name: "Corte de lenha",
    xp: "wood",
    tiers: [
      { name: "Retorcida", level: 1, resource: "wood", interval: 8, base: 1, xp: 4 },
      { name: "Bétula", level: 12, resource: "birch", interval: 11, base: 1, xp: 8 },
      { name: "Sombria", level: 30, resource: "darkwood", interval: 15, base: 1, xp: 16 },
      { name: "Ancestral", level: 55, resource: "elderwood", interval: 20, base: 1, xp: 30 },
    ],
  },
  fishing: {
    name: "Pesca",
    xp: "fishing",
    tiers: [
      { name: "Riacho", level: 1, resource: "fish", interval: 11, base: 1, xp: 4 },
      { name: "Truta", level: 12, resource: "trout", interval: 14, base: 1, xp: 9 },
      { name: "Enguia", level: 30, resource: "eel", interval: 18, base: 1, xp: 16 },
      { name: "Abismo", level: 55, resource: "abyssfish", interval: 24, base: 1, xp: 32 },
    ],
  },
  smithing: {
    name: "Metalurgia",
    xp: "smithing",
    tiers: [
      { name: "Cobre", level: 1, resource: "barCopper", interval: 18, base: 1, xp: 6, cost: { oreCopper: 3 } },
      { name: "Ferro", level: 8, resource: "barIron", interval: 22, base: 1, xp: 12, cost: { oreIron: 3 } },
      { name: "Prata", level: 18, resource: "barSilver", interval: 26, base: 1, xp: 18, cost: { oreSilver: 3 } },
    ],
  },
  cooking: {
    name: "Culinária",
    xp: "cooking",
    tiers: [
      { name: "Assado", level: 1, resource: "food", interval: 16, base: 1, xp: 5, cost: { fish: 2 } },
      { name: "Defumado", level: 12, resource: "foodBig", interval: 20, base: 1, xp: 10, cost: { trout: 2 } },
      { name: "Ensopado", level: 30, resource: "foodEel", interval: 24, base: 1, xp: 16, cost: { eel: 2 } },
    ],
  },
};

export type JobId = keyof typeof workerJobs;

export const workerNames = ["Borin", "Mira", "Tomas", "Edda", "Rurik", "Lysa", "Darian", "Nessa", "Oren", "Syla"];
export const hireCosts = [180, 420, 900, 1800, 3600, 7200];

export const propertyDefs = {
  house: { name: "Casa do Aventureiro", desc: "Um lar seguro. Aumenta o espaço de armazenamento.", cost: { wood: 35, oreCopper: 12 }, max: 5 },
  warehouse: { name: "Depósito", desc: "Amplia bastante a capacidade de materiais.", cost: { wood: 45, oreCopper: 18 }, max: 8 },
  workshop: { name: "Oficina", desc: "Metalúrgicos e cozinheiros contratados produzem +1 por ciclo.", cost: { wood: 30, barCopper: 8 }, max: 5 },
  garden: { name: "Horta", desc: "Gera comida periodicamente enquanto o vale segue desperto.", cost: { wood: 25, fish: 4 }, max: 5 },
} as const;

export type PropertyId = keyof typeof propertyDefs;

export const petDefs = [
  { id: "mossling", name: "Musguinho", cost: 260, bonus: "gather" as const, desc: "+1 recurso por ciclo de coleta e de servo." },
  { id: "emberfox", name: "Raposa Ígnea", cost: 520, bonus: "xp" as const, desc: "+12% de experiência em todas as perícias." },
  { id: "stonecub", name: "Filhote de Pedra", cost: 850, bonus: "def" as const, desc: "Reduz o dano recebido em combate em 8%." },
  { id: "nightowl", name: "Coruja Noturna", cost: 1200, bonus: "offline" as const, desc: "+2 horas no limite de progresso offline." },
];

export type PetBonus = (typeof petDefs)[number]["bonus"];

export const contractPool = [
  { id: "slay5", title: "Ameaça nas estradas", desc: "Derrote 5 monstros.", type: "kills" as const, goal: 5, gold: 180, xp: 90 },
  { id: "slay12", title: "Caçador incansável", desc: "Derrote 12 monstros.", type: "kills" as const, goal: 12, gold: 420, xp: 220 },
  { id: "skill25", title: "Mãos laboriosas", desc: "Conclua 25 ações de perícia.", type: "actions" as const, goal: 25, gold: 160, xp: 110 },
  { id: "skill60", title: "Ofício aperfeiçoado", desc: "Conclua 60 ações de perícia.", type: "actions" as const, goal: 60, gold: 360, xp: 240 },
  { id: "servant20", title: "Uma equipe produtiva", desc: "Seus servos devem concluir 20 tarefas.", type: "workers" as const, goal: 20, gold: 300, xp: 160 },
];

export type Contract = (typeof contractPool)[number];
