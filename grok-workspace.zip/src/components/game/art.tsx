import { itemIcon, skillIcon, type SkillId } from "@/game/data";

export function Ico({ id, alt = "" }: { id: string; alt?: string }) {
  return <img className="ico" src={itemIcon(id)} alt={alt} />;
}

export function SkillIco({ id }: { id: SkillId }) {
  return <img className="ico" src={skillIcon(id)} alt="" />;
}

function wide(src: string) {
  return /mine|fish|rat|wolf|drake|spider/.test(src);
}

export function Diorama({
  scene,
  pose,
  foe,
  label,
  pet,
  merchants,
  splash,
}: {
  scene: string;
  pose?: string;
  foe?: string;
  label?: string;
  pet?: string | null;
  merchants?: boolean;
  splash?: { n: number; text: string; k: string } | null;
}) {
  return (
    <div className="diorama">
      <img className="bg" src={scene} alt="" />
      {label ? <span className="stage-label">{label}</span> : null}
      {merchants ? (
        <>
          <img className="actor left bob" src="/pixel/pedro.png" alt="Pedro, mercador" />
          <img className="actor right flip bob" src="/pixel/luan.png" alt="Luan, mercador" />
        </>
      ) : (
        <>
          {pose ? <img className={`actor left bob${wide(pose) ? " wide" : ""}`} src={pose} alt="" /> : null}
          {foe ? <img className={`actor right foe bob${wide(foe) ? " wide" : ""}`} src={foe} alt="" /> : null}
          {pet ? <img className="pet bob" src={pet} alt="" /> : null}
          {splash ? (
            <b key={splash.n} className={`floater ${splash.k}`}>
              {splash.text}
            </b>
          ) : null}
        </>
      )}
    </div>
  );
}

export function Bar({ value, kind = "xp", label }: { value: number; kind?: "xp" | "hp" | "danger"; label?: string }) {
  return (
    <div className="bar-wrap">
      <div className={`bar ${kind}`} aria-hidden>
        <i style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
      </div>
      {label ? <span className="bar-label">{label}</span> : null}
    </div>
  );
}
