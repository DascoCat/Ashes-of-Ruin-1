import { useEffect, useState, useSyncExternalStore, type ReactNode } from "react";
import {
  foods,
  gearStats,
  heroPose,
  hireCosts,
  itemBlurb,
  items,
  monsterSrc,
  nodes,
  petArt,
  petDefs,
  propertyDefs,
  recipes,
  sceneForSkill,
  skillIcon,
  skills,
  stalls,
  workerJobs,
  zoneScenes,
  zones,
  type JobId,
  type PropertyId,
  type SkillId,
  type StallId,
} from "@/game/data";
import {
  actionClock,
  actionLabel,
  adoptPet,
  askReset,
  boot,
  build,
  cancelReset,
  catchUp,
  claimContract,
  costText,
  equipItem,
  exportCode,
  fmtDur,
  frame,
  getRev,
  getSave,
  getUI,
  hireWorker,
  importCode,
  inv,
  levelEta,
  lvl,
  marketTrade,
  need,
  notify,
  num,
  openSkill,
  pct,
  playerStats,
  resetGame,
  saveNow,
  setPet,
  setStyle,
  setTab,
  setWorkerJob,
  setWorkerTier,
  speedMult,
  startCombat,
  startSkill,
  stop,
  storageCapacity,
  subscribe,
  toggleAuto,
  toggleWorker,
  totalLevel,
  unlockZone,
  useItem,
  usedStorage,
  workerPlan,
  type LogLine,
  type Tab,
} from "@/game/engine";
import { Bar, Diorama, Ico, SkillIco } from "./art";

function useGame() {
  useSyncExternalStore(subscribe, getRev, getRev);
  return { S: getSave(), ui: getUI() };
}

const jobIcon: Record<JobId, string> = {
  mining: "/pixel/ico-pick.png",
  wood: "/pixel/ico-axe.png",
  fishing: "/pixel/ico-rod.png",
  smithing: "/pixel/ico-anvil.png",
  cooking: "/pixel/ico-pot.png",
};

const slotName = { weapon: "Arma", armor: "Armadura", tool: "Ferramenta", accessory: "Manto" } as const;

function gearable(id: string) {
  return Boolean(gearStats[id]);
}
function edible(id: string) {
  return id in foods;
}

function pace(seconds: number, xp: number, skill: SkillId) {
  const mult = speedMult(skill);
  const pet = getSave().activePet;
  const xpBonus = pet && petDefs.find((p) => p.id === pet)?.bonus === "xp" ? 1.12 : 1;
  const perHour = 3600 / (seconds * mult);
  return `${num(perHour)} ações/h · ${num(perHour * xp * xpBonus)} XP/h · ${fmtDur(seconds * mult)} cada`;
}

function LogList({ lines }: { lines: LogLine[] }) {
  if (!lines.length) return <p className="tiny">Os golpes aparecem aqui, um por turno.</p>;
  return (
    <ol className="log">
      {lines.map((line, i) => (
        <li key={`${i}-${line.text}`} className={line.k}>
          {line.text}
        </li>
      ))}
    </ol>
  );
}

function visual() {
  const S = getSave();
  const pet = S.activePet ? petArt[S.activePet] : null;
  const a = S.action;
  if (!a) return { scene: "/pixel/scene-camp.jpg", pose: "/pixel/hero-idle.png", foe: undefined as string | undefined, label: "Acampamento", pet };
  if (a.type === "combat") {
    const m = zones[a.zone]?.monsters[a.index];
    return {
      scene: zoneScenes[a.zone] || zoneScenes[0],
      pose: "/pixel/hero-fight.png",
      foe: m ? monsterSrc(m.name) : undefined,
      label: zones[a.zone]?.name || "Combate",
      pet,
    };
  }
  const skill = skills.find((s) => s.id === a.skill);
  return { scene: sceneForSkill(a.skill), pose: heroPose(a.skill), foe: undefined, label: skill?.name || "Ofício", pet };
}

function HomePage() {
  const { S, ui } = useGame();
  const p = playerStats();
  const act = actionLabel();
  const view = visual();
  const clock = actionClock();
  return (
    <>
      <Diorama scene={view.scene} pose={view.pose} foe={view.foe} label={view.label} pet={view.pet} splash={ui.splash} />
      <section className="panel">
        <div className="kicker">Vale de Véspera</div>
        <h2>O último fogo ainda trabalha.</h2>
        <p className="tiny">Não há herói escolhido. Você treina o ofício, e o ofício responde — mesmo com a tela fechada.</p>
      </section>
      <div className="stats">
        <div className="stat">
          Ataque<b>{p.atk}</b>
        </div>
        <div className="stat">
          Defesa<b>{p.def}</b>
        </div>
        <div className="stat">
          Nível total<b>{totalLevel()}</b>
        </div>
      </div>
      <section className="panel stack">
        <div className="row">
          <div>
            <div className="kicker">Atividade</div>
            <h3>{act.title}</h3>
            <p className="tiny">{act.detail}</p>
          </div>
          <span className="tag">{clock ? fmtDur(clock.left) : act.kind}</span>
        </div>
        {S.action && clock ? <Bar value={Math.min(100, S.progress * 100)} label={`falta ${fmtDur(clock.left)} neste ciclo`} /> : null}
        {S.action?.type === "combat" ? <LogList lines={S.log.slice(0, 4)} /> : null}
        {S.action ? (
          <button className="ghost" onClick={stop}>
            Parar atividade
          </button>
        ) : (
          <button className="btn go" onClick={() => setTab("skills")}>
            Escolher um ofício
          </button>
        )}
      </section>
      <div className="links">
        <button className="btn" onClick={() => setTab("combat")}>
          <b>Combate</b>
          <small className="tiny">Regiões e chefes</small>
        </button>
        <button className="btn" onClick={() => setTab("items")}>
          <b>Banco</b>
          <small className="tiny">
            {num(usedStorage())}/{num(storageCapacity())}
          </small>
        </button>
        <button className="btn" onClick={() => setTab("market")}>
          <b>Mercado</b>
          <small className="tiny">Pedro e Luan</small>
        </button>
        <button className="btn" onClick={() => setTab("workers")}>
          <b>Servos</b>
          <small className="tiny">{S.workers.length} na folha</small>
        </button>
      </div>
    </>
  );
}

function SkillsPage() {
  const { S } = useGame();
  const groups = ["Combate", "Coleta", "Produção"] as const;
  return (
    <>
      <section className="panel">
        <div className="kicker">Doze ofícios</div>
        <h2>Perícias</h2>
        <p className="tiny">Nível total {totalLevel()}. Toque um ofício para treinar. Combate sobe na luta.</p>
      </section>
      {groups.map((g) => (
        <section key={g} className="stack">
          <div className="kicker">{g}</div>
          <div className="skills">
            {skills
              .filter((s) => s.group === g)
              .map((s) => {
                const on = S.action?.type === "skill" && S.action.skill === s.id;
                return (
                  <button key={s.id} className={`btn skill${on ? " on" : ""}`} onClick={() => openSkill(s.id)}>
                    <SkillIco id={s.id} />
                    <span>{s.name}</span>
                    <b>{lvl(s.id)}</b>
                    <Bar value={pct(s.id)} />
                    <small className="tiny">{num(Math.max(0, need(s.id) - (S.levels[s.id]?.xp || 0)))} XP</small>
                  </button>
                );
              })}
          </div>
        </section>
      ))}
    </>
  );
}

function DetailPage() {
  const { S, ui } = useGame();
  const id = ui.selected;
  const skill = skills.find((s) => s.id === id);
  if (!skill) return null;
  const list = nodes[id] || recipes[id];
  const eta = levelEta(id);
  const clock = actionClock();
  if (!list) {
    return (
      <section className="panel stack">
        <button className="btn" onClick={() => setTab("skills")}>
          Voltar aos ofícios
        </button>
        <SkillIco id={id} />
        <h2>
          {skill.name} · {lvl(id)}
        </h2>
        <Bar value={pct(id)} />
        <p>Esta perícia sobe no combate, de acordo com o estilo da luta.</p>
        <button className="btn go" onClick={() => setTab("combat")}>
          Ir para o combate
        </button>
      </section>
    );
  }
  return (
    <>
      <button className="btn" onClick={() => setTab("skills")}>
        Voltar aos ofícios
      </button>
      <Diorama scene={sceneForSkill(id)} pose={heroPose(id)} label={`${skill.name} · nível ${lvl(id)}`} splash={S.action?.type === "skill" && S.action.skill === id ? ui.splash : null} />
      <section className="panel stack">
        <div className="row">
          <h2>{skill.name}</h2>
          <span className="tag">{num(S.levels[id].xp)} XP</span>
        </div>
        <Bar value={pct(id)} />
        <p className="tiny">
          A barra de cima continua mesmo se você trocar de tela.
          {id === "mining" && speedMult("mining") < 1 ? ` ${gearStats[S.equip.tool || ""]?.label}.` : " Escolha um nó e deixe rodar."}
        </p>
        {eta != null ? <p className="tiny">Neste ritmo, o próximo nível chega em cerca de {fmtDur(eta)}.</p> : null}
      </section>
      <div className="stack">
        {list.map((row, i) => {
          const on = S.action?.type === "skill" && S.action.skill === id && S.action.index === i;
          const locked = lvl(id) < row.level;
          const cost = "cost" in row ? row.cost : undefined;
          return (
            <article className="entry stack" key={row.name}>
              <div className="row">
                <strong className="row">
                  <Ico id={row.item} alt="" /> {row.name}
                </strong>
                <span className="tiny">Nív. {row.level}</span>
              </div>
              <p className="tiny">
                {row.seconds}s · +{row.xp} XP · {cost ? "produz 1" : "+1 recurso"} · na mochila {num(inv(row.item))}
              </p>
              <p className="tiny">{pace(row.seconds, row.xp, id)}</p>
              {itemBlurb(row.item) ? <p className="tiny">{itemBlurb(row.item)}</p> : null}
              {cost ? <p className="tiny">Gasta: {costText(cost as Record<string, number>)}</p> : null}
              <button className={`btn${on ? " on" : " go"}`} disabled={locked} onClick={() => startSkill(id, i)}>
                {locked ? "Bloqueado" : on && clock ? `Treinando · ${fmtDur(clock.left)}` : "Treinar"}
              </button>
            </article>
          );
        })}
      </div>
    </>
  );
}

function CombatPage() {
  const { S, ui } = useGame();
  const [focus, setFocus] = useState(0);
  const p = playerStats();
  const a = S.action?.type === "combat" ? S.action : null;
  const zone = zones[a ? a.zone : focus];
  const mon = a ? zone?.monsters[a.index] : null;
  const hpPct = mon ? Math.max(0, ((S.battle?.hp ?? mon.hp) / mon.hp) * 100) : 0;
  const clock = actionClock();
  const pantry = Object.entries(foods).filter(([id]) => inv(id) > 0);
  return (
    <>
      <Diorama
        scene={zoneScenes[a ? a.zone : focus] || zoneScenes[0]}
        pose="/pixel/hero-fight.png"
        foe={mon ? monsterSrc(mon.name) : undefined}
        label={mon ? mon.name : zone?.name}
        splash={a ? ui.splash : null}
      />
      <section className="panel stack">
        <div className="stats">
          <div className="stat">
            ATK<b>{p.atk}</b>
          </div>
          <div className="stat">
            DEF<b>{p.def}</b>
          </div>
          <div className="stat">
            MAG<b>{p.magic}</b>
          </div>
        </div>
        <Bar value={(S.hp / Math.max(1, p.max)) * 100} kind="hp" label={`${S.hp}/${p.max} de vida`} />
        <div className="actions">
          {(
            [
              ["attack", "Espada"],
              ["ranged", "Arco"],
              ["magic", "Magia"],
            ] as const
          ).map(([id, label]) => (
            <button key={id} className={`btn${S.style === id ? " on" : ""}`} onClick={() => setStyle(id)}>
              {label}
            </button>
          ))}
        </div>
        <div className="actions">
          <button className={`btn${S.autoCombat ? " on" : ""}`} onClick={() => toggleAuto("autoCombat")}>
            Auto luta: {S.autoCombat ? "sim" : "não"}
          </button>
          <button className={`btn${S.autoFood ? " on" : ""}`} onClick={() => toggleAuto("autoFood")}>
            Comer auto: {S.autoFood ? "sim" : "não"}
          </button>
        </div>
        <p className="tiny">
          {pantry.length
            ? `Despensa: ${pantry.map(([id, heal]) => `${items[id]?.name} ×${inv(id)} (+${heal})`).join(" · ")}`
            : "Sem comida. O auto-comer não tem o que usar."}
        </p>
      </section>
      {mon ? (
        <section className="panel stack">
          <div className="row">
            <strong>{mon.name}</strong>
            <span className="tiny">{clock ? fmtDur(clock.left) : `Turno ${S.turn + 1}`}</span>
          </div>
          <Bar value={hpPct} kind="danger" label={`${Math.max(0, Math.round(S.battle?.hp ?? mon.hp))}/${mon.hp} HP · saque ${items[mon.loot]?.name}`} />
        </section>
      ) : null}
      <section className="panel stack">
        <div className="kicker">Registro da luta</div>
        <LogList lines={S.log} />
      </section>
      <div className="kicker">Regiões</div>
      {zones.map((z, zi) => (
        <section className="panel stack" key={z.name}>
          <button className="btn" onClick={() => setFocus(zi)}>
            <span className="row">
              <b>{z.name}</b>
              <span className="tiny">Nív. {z.level}+</span>
            </span>
          </button>
          {S.unlocked.includes(zi) ? (
            z.monsters.map((m, mi) => {
              const on = a?.zone === zi && a.index === mi;
              return (
                <article className="entry stack" key={m.name}>
                  <div className="row">
                    <strong className="row">
                      <img className="mini" src={monsterSrc(m.name)} alt="" /> {m.name}
                    </strong>
                    <span className="tiny">Nív. {m.level}</span>
                  </div>
                  <p className="tiny">
                    HP {num(m.hp)} · ATK {m.atk} · {num(m.gold)} ouro · {items[m.loot]?.name}
                  </p>
                  <button className={`btn${on ? " on" : " go"}`} onClick={() => startCombat(zi, mi)}>
                    {on ? "Em combate" : "Enfrentar"}
                  </button>
                </article>
              );
            })
          ) : (
            <>
              <p className="tiny">Área bloqueada · {num(z.cost)} ouro. A anterior precisa estar aberta.</p>
              <button className="btn go" onClick={() => unlockZone(zi)}>
                Desbloquear
              </button>
            </>
          )}
        </section>
      ))}
    </>
  );
}

function ItemsPage() {
  const { S } = useGame();
  const [sel, setSel] = useState<string | null>(null);
  const entries = Object.entries(S.inventory).filter(([, v]) => v > 0);
  const picked = sel && inv(sel) > 0 ? sel : null;
  return (
    <>
      <section className="panel stack">
        <div className="kicker">Banco</div>
        <h2>Mochila</h2>
        <Bar value={(usedStorage() / Math.max(1, storageCapacity())) * 100} />
        <p className="tiny">
          {num(usedStorage())} / {num(storageCapacity())} ocupado. Depósito e casa aumentam o limite.
        </p>
        <div className="bank">
          {(Object.keys(slotName) as (keyof typeof slotName)[]).map((slot) => {
            const id = S.equip[slot];
            return (
              <button key={slot} className={`slot${id ? " on" : ""}`} onClick={() => id && equipItem(id)} disabled={!id}>
                {id ? <Ico id={id} alt={items[id]?.name || ""} /> : <span className="tiny">{slotName[slot]}</span>}
              </button>
            );
          })}
        </div>
      </section>
      {entries.length ? (
        <div className="bank">
          {entries.map(([id, qty]) => (
            <button key={id} className={`slot${picked === id ? " on" : ""}`} onClick={() => setSel(id)}>
              <Ico id={id} alt={items[id]?.name || id} />
              <span className="count">{num(qty)}</span>
            </button>
          ))}
        </div>
      ) : (
        <section className="panel">
          <p>O banco está vazio. Mine, corte ou pesque para encher as prateleiras.</p>
        </section>
      )}
      {picked ? (
        <section className="panel stack">
          <div className="row">
            <strong className="row">
              <Ico id={picked} alt="" /> {items[picked]?.name || picked}
            </strong>
            <b>{num(inv(picked))}×</b>
          </div>
          {itemBlurb(picked) ? <p className="tiny">{itemBlurb(picked)}</p> : <p className="tiny">Material. Serve para ofício, servo ou venda.</p>}
          <div className="actions">
            {edible(picked) ? (
              <button className="btn go" onClick={() => useItem(picked)}>
                Usar · +{foods[picked]}
              </button>
            ) : null}
            {gearable(picked) ? (
              <button className="btn go" onClick={() => equipItem(picked)}>
                {Object.values(S.equip).includes(picked) ? "Guardar" : "Equipar"}
              </button>
            ) : null}
          </div>
        </section>
      ) : null}
    </>
  );
}

function MarketPage() {
  const { S } = useGame();
  const [stall, setStall] = useState<StallId>("pedro");
  const shop = stalls[stall];
  return (
    <>
      <Diorama scene="/pixel/scene-market.jpg" merchants label="Mercado de Véspera" />
      <section className="panel stack">
        <div className="kicker">Dois mercadores, nenhum herói</div>
        <h2>{shop.name}</h2>
        <p>{shop.role}</p>
        <p className="tiny">{shop.line}</p>
        <p className="tiny">
          Seu ouro: {num(S.gold)}. Venda aqui rende {Math.round(shop.sell * 100)}% do preço de compra.
        </p>
        <div className="actions">
          <button className={`btn${stall === "pedro" ? " on" : ""}`} onClick={() => setStall("pedro")}>
            Pedro · trilha
          </button>
          <button className={`btn${stall === "luan" ? " on" : ""}`} onClick={() => setStall("luan")}>
            Luan · oficina
          </button>
        </div>
      </section>
      <div className="stack">
        {shop.goods.map((g) => (
          <article className="entry stack" key={g.id}>
            <div className="row">
              <strong className="row">
                <Ico id={g.id} alt="" /> {items[g.id]?.name || g.id}
              </strong>
              <span className="tiny">{g.price} ouro</span>
            </div>
            <p className="tiny">
              Na mochila: {num(inv(g.id))} · vende por {Math.floor(g.price * shop.sell)}
            </p>
            <div className="actions">
              <button className="btn" onClick={() => marketTrade(stall, g.id, 1, "buy")}>
                Comprar 1
              </button>
              <button className="btn" onClick={() => marketTrade(stall, g.id, 10, "buy")}>
                Comprar 10
              </button>
              <button className="btn" onClick={() => marketTrade(stall, g.id, 1, "sell")}>
                Vender 1
              </button>
              <button className="btn" onClick={() => marketTrade(stall, g.id, 10, "sell")}>
                Vender 10
              </button>
            </div>
          </article>
        ))}
      </div>
    </>
  );
}

function WorkersPage() {
  const { S } = useGame();
  const next = hireCosts[Math.min(S.workers.length, hireCosts.length - 1)];
  return (
    <>
      <section className="panel stack">
        <div className="kicker">Folha de pagamento</div>
        <h2>Servos</h2>
        <div className="stats">
          <div className="stat">
            Equipe<b>{S.workers.length}/6</b>
          </div>
          <div className="stat">
            Tarefas<b>{num(S.stats.workerActions || 0)}</b>
          </div>
          <div className="stat">
            Ouro<b>{num(S.gold)}</b>
          </div>
        </div>
        <p className="tiny">
          Por padrão o servo pega o melhor nó que a sua perícia já abriu. Prenda um nó se ainda precisar do básico. Sem ouro, material ou espaço, ele pausa.
        </p>
      </section>
      <div className="hire">
        {(Object.keys(workerJobs) as JobId[]).map((k) => (
          <button key={k} className="btn" disabled={S.workers.length >= 6} onClick={() => hireWorker(k)}>
            <img className="ico" src={jobIcon[k]} alt="" />
            <span>{workerJobs[k].name}</span>
            <small className="tiny">{num(next)} ouro</small>
          </button>
        ))}
      </div>
      <div className="stack">
        {S.workers.length ? (
          S.workers.map((w) => {
            const plan = workerPlan(w);
            const job = plan.job;
            const needXp = 45 * w.level * w.level;
            const left = Math.max(0, plan.tier.interval - (w.progress || 0));
            return (
              <article className="entry stack" key={w.id}>
                <div className="row">
                  <strong className="row">
                    <img className="mini" src={heroPose(job.xp)} alt="" /> {w.name}
                  </strong>
                  <span className="tag">Nív. {w.level}</span>
                </div>
                <p className="tiny">
                  {w.active ? "Trabalhando" : "Pausado"} · {items[plan.tier.resource]?.name} · {w.active ? `próximo em ${fmtDur(left)}` : "ciclo parado"}
                </p>
                <Bar value={Math.min(100, ((w.progress || 0) / plan.tier.interval) * 100)} label={`ciclo · sua perícia está no nível ${lvl(job.xp)}`} />
                <div className="row">
                  <select aria-label={`Ofício de ${w.name}`} value={w.job} onChange={(e) => setWorkerJob(w.id, e.target.value as JobId)}>
                    {(Object.keys(workerJobs) as JobId[]).map((k) => (
                      <option key={k} value={k}>
                        {workerJobs[k].name}
                      </option>
                    ))}
                  </select>
                  <button className={`btn${w.active ? "" : " go"}`} onClick={() => toggleWorker(w.id)}>
                    {w.active ? "Pausar" : "Retomar"}
                  </button>
                </div>
                <select aria-label={`Nó de ${w.name}`} value={w.tier == null || w.tier < 0 ? -1 : w.tier} onChange={(e) => setWorkerTier(w.id, Number(e.target.value))}>
                  <option value={-1}>Melhor nó aberto</option>
                  {job.tiers.map((t, i) => (
                    <option key={t.resource} value={i} disabled={lvl(job.xp) < t.level}>
                      {lvl(job.xp) < t.level ? `${t.name} · trancado no ${t.level}` : `${t.name} · ${items[t.resource]?.name}`}
                    </option>
                  ))}
                </select>
                <p className="tiny">
                  Salário {1 + Math.floor((w.level - 1) / 3)} ouro · ciclo {plan.tier.interval}s
                  {plan.tier.cost ? ` · gasta ${costText(plan.tier.cost)}` : ""} · servo {Math.round(Math.min(100, ((w.xp || 0) / needXp) * 100))}% do nível
                </p>
              </article>
            );
          })
        ) : (
          <section className="panel">
            <p>Ninguém na folha ainda. Contrate um ofício acima.</p>
          </section>
        )}
      </div>
    </>
  );
}

function PropertyPage() {
  const { S } = useGame();
  return (
    <>
      <Diorama scene="/pixel/scene-home.jpg" pose="/pixel/hero-idle.png" label="Seu terreno" pet={S.activePet ? petArt[S.activePet] : null} />
      <section className="panel stack">
        <div className="kicker">Propriedade</div>
        <h2>Refúgio</h2>
        <div className="stats">
          <div className="stat">
            Níveis<b>{Object.values(S.property).reduce((a, b) => a + b, 0)}</b>
          </div>
          <div className="stat">
            Banco<b>
              {num(usedStorage())}/{num(storageCapacity())}
            </b>
          </div>
          <div className="stat">
            Servos<b>{S.workers.length}/6</b>
          </div>
        </div>
      </section>
      {(Object.keys(propertyDefs) as PropertyId[]).map((k) => {
        const d = propertyDefs[k];
        const lv = S.property[k] || 0;
        const cost: Record<string, number> = {};
        Object.entries(d.cost).forEach(([id, n]) => {
          cost[id] = n * (lv + 1);
        });
        return (
          <article className="entry stack" key={k}>
            <div className="row">
              <strong>{d.name}</strong>
              <span className="tag">
                {lv}/{d.max}
              </span>
            </div>
            <p className="tiny">{d.desc}</p>
            <p className="tiny">{lv >= d.max ? "Nível máximo." : `Próxima: ${costText(cost)}`}</p>
            <button className="btn go" disabled={lv >= d.max} onClick={() => build(k)}>
              {lv >= d.max ? "Máximo" : lv ? "Aprimorar" : "Construir"}
            </button>
          </article>
        );
      })}
    </>
  );
}

function PetsPage() {
  const { S } = useGame();
  const active = S.pets.find((p) => p.id === S.activePet);
  return (
    <>
      <section className="panel stack">
        <div className="kicker">Companheiros</div>
        <h2>Mascotes</h2>
        <p className="tiny">Um de cada vez. O bônus vale para o vale inteiro, não para um personagem.</p>
        <p>
          Ativo: <b>{active?.name || "Nenhum"}</b>
        </p>
      </section>
      <div className="stack">
        {petDefs.map((p) => {
          const owned = S.pets.some((x) => x.id === p.id);
          const on = S.activePet === p.id;
          return (
            <article className="entry stack" key={p.id}>
              <div className="row">
                <strong className="row">
                  <img className="mini" src={petArt[p.id]} alt="" /> {p.name}
                </strong>
                <span className="tag">{owned ? (on ? "junto" : "no lar") : `${num(p.cost)} ouro`}</span>
              </div>
              <p className="tiny">{p.desc}</p>
              <button className={`btn${on ? "" : " go"}`} onClick={() => (owned ? setPet(p.id) : adoptPet(p.id))}>
                {owned ? (on ? "Guardar" : "Levar junto") : "Adotar"}
              </button>
            </article>
          );
        })}
      </div>
    </>
  );
}

function ContractsPage() {
  const { S } = useGame();
  return (
    <>
      <section className="panel stack">
        <div className="kicker">Quadro do vale</div>
        <h2>Contratos</h2>
        <p className="tiny">
          Renovam com o dia do aparelho. Resgatados {S.contractClaimed.length}/{(S.dailyContracts || []).length}.
        </p>
      </section>
      <div className="stack">
        {(S.dailyContracts || []).map((q) => {
          const v = S.contractCounts[q.type] || 0;
          const done = v >= q.goal;
          const claimed = S.contractClaimed.includes(q.id);
          const icon = q.type === "kills" ? "/pixel/ico-sword.png" : q.type === "workers" ? "/pixel/ico-axe.png" : "/pixel/ico-anvil.png";
          return (
            <article className="entry stack" key={q.id}>
              <div className="row">
                <strong className="row">
                  <img className="ico" src={icon} alt="" /> {q.title}
                </strong>
                <span className="tag">{claimed ? "resgatado" : done ? "pronto" : "aberto"}</span>
              </div>
              <p className="tiny">{q.desc}</p>
              <Bar value={Math.min(100, (v / q.goal) * 100)} />
              <div className="row">
                <span className="tiny">
                  {Math.min(v, q.goal)}/{q.goal} · {q.gold} ouro + {q.xp} XP + 1 gema
                </span>
                <button className="btn go" disabled={!done || claimed} onClick={() => claimContract(q.id)}>
                  {claimed ? "Feito" : "Resgatar"}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}

function MapPage() {
  return (
    <>
      <section className="panel">
        <div className="kicker">Terras da ruína</div>
        <h2>Mapa</h2>
        <p className="tiny">Seis fronteiras. Cada uma abre depois da anterior.</p>
      </section>
      {zones.map((z, i) => (
        <article className="entry" key={z.name}>
          <img className="thumb" src={zoneScenes[i]} alt="" />
          <div className="row">
            <strong>{z.name}</strong>
            <span className="tag">{getSave().unlocked.includes(i) ? "aberta" : "fechada"}</span>
          </div>
          <p className="tiny">
            Nível {z.level}+ · {z.monsters.length} encontros · {z.monsters.at(-1)?.name}
          </p>
          <button className="btn" onClick={() => setTab("combat")}>
            Ir ao combate
          </button>
        </article>
      ))}
    </>
  );
}

function ExtrasPage() {
  const { S, ui } = useGame();
  const [code, setCode] = useState("");
  const [paste, setPaste] = useState("");
  return (
    <>
      <section className="panel stack">
        <div className="kicker">Crônica</div>
        <h2>O último fogo</h2>
        <p>Quando o sol sumiu sobre Véspera, as cinzas passaram a alimentar a terra. Cada ofício dominado é uma centelha contra o escuro. Pedro vende o que a trilha ainda dá. Luan compra o que as suas mãos fazem.</p>
      </section>
      <section className="panel stack">
        <h3>Marcas</h3>
        <p>Monstros derrotados: {num(S.kills)}</p>
        <p>Ações: {num(S.stats.actions)}</p>
        <p>Itens fabricados: {num(S.stats.crafted)}</p>
        <p>Ouro agora: {num(S.gold)}</p>
      </section>
      <section className="panel stack">
        <h3>Salvamento</h3>
        <p className="tiny">Grava neste navegador. Fora da tela, o progresso entra por até 8 horas — 10 com a coruja.</p>
        <button
          className="btn go"
          onClick={() => {
            saveNow();
            notify("Progresso salvo");
          }}
        >
          Salvar agora
        </button>
        <button
          className="btn"
          onClick={() => {
            const raw = exportCode();
            setCode(raw);
            navigator.clipboard?.writeText(raw).then(
              () => notify("Save copiado"),
              () => notify("Copie o código abaixo"),
            );
          }}
        >
          Exportar save
        </button>
        {code ? <textarea readOnly value={code} aria-label="Código do save" /> : null}
        <input value={paste} placeholder="Cole um save exportado" onChange={(e) => setPaste(e.target.value)} aria-label="Importar save" />
        <button className="btn" onClick={() => importCode(paste)}>
          Importar save
        </button>
        {ui.confirmReset ? (
          <div className="actions">
            <button className="ghost" onClick={resetGame}>
              Apagar mesmo
            </button>
            <button className="btn" onClick={cancelReset}>
              Cancelar
            </button>
          </div>
        ) : (
          <button className="ghost" onClick={askReset}>
            Apagar progresso
          </button>
        )}
      </section>
    </>
  );
}

function MorePage() {
  const links: { tab: Tab; title: string; hint: string; icon: string }[] = [
    { tab: "market", title: "Mercado", hint: "Pedro e Luan", icon: "/pixel/ico-coins.png" },
    { tab: "workers", title: "Servos", hint: "Folha de ofício", icon: "/pixel/ico-axe.png" },
    { tab: "property", title: "Casa", hint: "Terreno e depósito", icon: "/pixel/ico-logs.png" },
    { tab: "map", title: "Mapa", hint: "Seis regiões", icon: "/pixel/ico-shield.png" },
    { tab: "pets", title: "Mascotes", hint: "Um bônus por vez", icon: "/pixel/ico-orb.png" },
    { tab: "contracts", title: "Contratos", hint: "Quadro do dia", icon: "/pixel/ico-meat.png" },
    { tab: "extras", title: "Crônicas", hint: "Save e marcas", icon: "/pixel/ico-flask.png" },
  ];
  return (
    <>
      <section className="panel">
        <div className="kicker">O resto do vale</div>
        <h2>Mais</h2>
      </section>
      <div className="links">
        {links.map((l) => (
          <button key={l.tab} className="btn" onClick={() => setTab(l.tab)}>
            <img className="ico" src={l.icon} alt="" />
            <b>{l.title}</b>
            <small className="tiny">{l.hint}</small>
          </button>
        ))}
      </div>
    </>
  );
}

const pages: Record<Tab, () => ReactNode> = {
  home: HomePage,
  skills: SkillsPage,
  detail: DetailPage,
  combat: CombatPage,
  workers: WorkersPage,
  property: PropertyPage,
  market: MarketPage,
  pets: PetsPage,
  contracts: ContractsPage,
  items: ItemsPage,
  map: MapPage,
  extras: ExtrasPage,
  more: MorePage,
};

const sideNav: { id: Tab; label: string; icon: string }[] = [
  { id: "home", label: "Vale", icon: "/pixel/ico-coins.png" },
  { id: "skills", label: "Ofícios", icon: skillIcon("mining") },
  { id: "combat", label: "Combate", icon: "/pixel/ico-sword.png" },
  { id: "items", label: "Banco", icon: "/pixel/ico-logs.png" },
  { id: "market", label: "Mercado", icon: "/pixel/ico-pot.png" },
  { id: "workers", label: "Servos", icon: "/pixel/ico-axe.png" },
  { id: "property", label: "Casa", icon: "/pixel/ico-shield.png" },
  { id: "map", label: "Mapa", icon: "/pixel/ico-bow.png" },
  { id: "pets", label: "Mascotes", icon: "/pixel/ico-orb.png" },
  { id: "contracts", label: "Contratos", icon: "/pixel/ico-meat.png" },
  { id: "extras", label: "Crônicas", icon: "/pixel/ico-flask.png" },
];

const dock: { id: Tab; label: string; icon: string }[] = [
  { id: "home", label: "Vale", icon: "/pixel/ico-coins.png" },
  { id: "skills", label: "Ofícios", icon: skillIcon("mining") },
  { id: "combat", label: "Luta", icon: "/pixel/ico-sword.png" },
  { id: "items", label: "Banco", icon: "/pixel/ico-logs.png" },
  { id: "more", label: "Mais", icon: "/pixel/ico-anvil.png" },
];

function Shell() {
  const { S, ui } = useGame();
  const p = playerStats();
  const act = actionLabel();
  const view = visual();
  const Page = pages[ui.tab] || HomePage;
  const moreOn = ["workers", "property", "market", "pets", "contracts", "map", "extras", "more"].includes(ui.tab);
  const hp = Math.max(0, (S.hp / Math.max(1, p.max)) * 100);
  const clock = actionClock();
  const jump = () => {
    const a = getSave().action;
    if (!a) setTab("skills");
    else if (a.type === "combat") setTab("combat");
    else openSkill(a.skill);
  };
  return (
    <div className="shell">
      <header className="top">
        <div className="top-row">
          <div className="brand">
            <b>ASHES OF RUIN</b>
            <small>Idle Chronicles</small>
          </div>
          <div className="hp">
            <b>
              {S.hp}/{p.max}
            </b>
            <div className="track hp">
              <i style={{ width: `${hp}%` }} />
            </div>
          </div>
          <div className="res">
            <img className="ico" src="/pixel/ico-coins.png" alt="" />
            <b>{num(S.gold)}</b>
          </div>
        </div>
        <div className="activity">
          <button className="activity-jump" onClick={jump}>
            <img className="mini" src={view.pose} alt="" />
            <div className="who">
              <span className="row">
                <strong>{act.title}</strong>
                <span className="eta">{clock ? fmtDur(clock.left) : "parado"}</span>
              </span>
              <div className="track">
                <i style={{ width: `${Math.max(0, Math.min(100, S.progress * 100))}%` }} />
              </div>
              <em className={ui.pulse ? "pulse" : "hint"} key={ui.pulse ? ui.pulseN : "idle"}>
                {ui.pulse || (S.action ? "Toque para abrir o ofício" : "Escolha um ofício")}
              </em>
            </div>
          </button>
          <button className="ghost" onClick={stop} disabled={!S.action}>
            Parar
          </button>
        </div>
      </header>
      <div className="workspace">
        <nav className="side" aria-label="Seções">
          {sideNav.map((item) => {
            const on = ui.tab === item.id || (ui.tab === "detail" && item.id === "skills");
            return (
              <button key={item.id} className={on ? "on" : ""} onClick={() => setTab(item.id)}>
                <img src={item.icon} alt="" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <main className="screen">
          <Page />
        </main>
      </div>
      <nav className="dock" aria-label="Navegação">
        {dock.map((item) => {
          const on = item.id === "more" ? moreOn : ui.tab === item.id || (ui.tab === "detail" && item.id === "skills");
          return (
            <button key={item.id} className={on ? "on" : ""} onClick={() => setTab(item.id)}>
              <img src={item.icon} alt="" />
              {item.label}
            </button>
          );
        })}
      </nav>
      {ui.toast ? (
        <div className="toast" role="status">
          {ui.toast}
        </div>
      ) : null}
    </div>
  );
}

export function GameApp() {
  useEffect(() => {
    boot();
    let last = performance.now();
    let raf = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      frame(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const timer = window.setInterval(saveNow, 5000);
    const hide = () => {
      if (document.hidden) saveNow();
      else catchUp();
    };
    document.addEventListener("visibilitychange", hide);
    window.addEventListener("beforeunload", saveNow);
    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", hide);
      window.removeEventListener("beforeunload", saveNow);
    };
  }, []);
  return <Shell />;
}
