//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CHEAqmBG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B_S5X9Hn.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B_S5X9Hn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BUAfFqaN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
