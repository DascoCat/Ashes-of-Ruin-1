import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-UpzRxU-M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SAVE_KEY = "ashes_idle_v03";
var skills = [
	{
		id: "attack",
		name: "Ataque",
		group: "Combate"
	},
	{
		id: "strength",
		name: "Força",
		group: "Combate"
	},
	{
		id: "defense",
		name: "Defesa",
		group: "Combate"
	},
	{
		id: "ranged",
		name: "Distância",
		group: "Combate"
	},
	{
		id: "magic",
		name: "Magia",
		group: "Combate"
	},
	{
		id: "wood",
		name: "Lenha",
		group: "Coleta"
	},
	{
		id: "mining",
		name: "Mineração",
		group: "Coleta"
	},
	{
		id: "fishing",
		name: "Pesca",
		group: "Coleta"
	},
	{
		id: "cooking",
		name: "Culinária",
		group: "Produção"
	},
	{
		id: "smithing",
		name: "Metalurgia",
		group: "Produção"
	},
	{
		id: "alchemy",
		name: "Alquimia",
		group: "Produção"
	},
	{
		id: "craft",
		name: "Artesanato",
		group: "Produção"
	}
];
var nodes = {
	mining: [
		{
			name: "Veio de Cobre",
			level: 1,
			seconds: 1.8,
			xp: 8,
			item: "oreCopper"
		},
		{
			name: "Veio de Ferro",
			level: 8,
			seconds: 3.2,
			xp: 23,
			item: "oreIron"
		},
		{
			name: "Veio de Prata",
			level: 18,
			seconds: 4.8,
			xp: 49,
			item: "oreSilver"
		},
		{
			name: "Veio de Cristal",
			level: 35,
			seconds: 6.5,
			xp: 110,
			item: "crystal"
		},
		{
			name: "Veio de Cinzálio",
			level: 55,
			seconds: 9,
			xp: 230,
			item: "oreAsh"
		}
	],
	wood: [
		{
			name: "Árvore Retorcida",
			level: 1,
			seconds: 2,
			xp: 8,
			item: "wood"
		},
		{
			name: "Bétula Pálida",
			level: 12,
			seconds: 3.5,
			xp: 27,
			item: "birch"
		},
		{
			name: "Madeira Sombria",
			level: 30,
			seconds: 5.5,
			xp: 75,
			item: "darkwood"
		},
		{
			name: "Árvore Ancestral",
			level: 55,
			seconds: 8,
			xp: 185,
			item: "elderwood"
		}
	],
	fishing: [
		{
			name: "Peixe do Riacho",
			level: 1,
			seconds: 2.4,
			xp: 9,
			item: "fish"
		},
		{
			name: "Truta das Cinzas",
			level: 12,
			seconds: 3.5,
			xp: 30,
			item: "trout"
		},
		{
			name: "Enguia Espectral",
			level: 30,
			seconds: 5.5,
			xp: 84,
			item: "eel"
		},
		{
			name: "Peixe Abissal",
			level: 55,
			seconds: 8,
			xp: 210,
			item: "abyssfish"
		}
	]
};
var recipes = {
	cooking: [
		{
			name: "Peixe Assado",
			level: 1,
			seconds: 3,
			xp: 15,
			cost: { fish: 2 },
			item: "food"
		},
		{
			name: "Truta Defumada",
			level: 12,
			seconds: 4,
			xp: 38,
			cost: {
				trout: 2,
				wood: 1
			},
			item: "foodBig"
		},
		{
			name: "Ensopado de Enguia",
			level: 30,
			seconds: 5,
			xp: 90,
			cost: {
				eel: 2,
				birch: 1
			},
			item: "foodEel"
		},
		{
			name: "Banquete Abissal",
			level: 55,
			seconds: 7,
			xp: 210,
			cost: {
				abyssfish: 2,
				darkwood: 1
			},
			item: "foodAbyss"
		}
	],
	smithing: [
		{
			name: "Barra de Cobre",
			level: 1,
			seconds: 4,
			xp: 18,
			cost: { oreCopper: 3 },
			item: "barCopper"
		},
		{
			name: "Espada de Cobre",
			level: 3,
			seconds: 7,
			xp: 38,
			cost: {
				barCopper: 4,
				wood: 2
			},
			item: "swordCopper"
		},
		{
			name: "Picareta de Cobre",
			level: 4,
			seconds: 7,
			xp: 40,
			cost: {
				barCopper: 3,
				wood: 2
			},
			item: "pickCopper"
		},
		{
			name: "Barra de Ferro",
			level: 8,
			seconds: 5,
			xp: 38,
			cost: { oreIron: 3 },
			item: "barIron"
		},
		{
			name: "Picareta de Ferro",
			level: 10,
			seconds: 8,
			xp: 55,
			cost: {
				barIron: 3,
				wood: 2
			},
			item: "pickIron"
		},
		{
			name: "Espada de Ferro",
			level: 12,
			seconds: 10,
			xp: 75,
			cost: {
				barIron: 5,
				wood: 3
			},
			item: "swordIron"
		},
		{
			name: "Armadura de Ferro",
			level: 16,
			seconds: 12,
			xp: 90,
			cost: { barIron: 8 },
			item: "armorIron"
		},
		{
			name: "Barra de Prata",
			level: 18,
			seconds: 6,
			xp: 70,
			cost: { oreSilver: 3 },
			item: "barSilver"
		},
		{
			name: "Lâmina de Prata",
			level: 24,
			seconds: 11,
			xp: 120,
			cost: {
				barSilver: 5,
				birch: 2
			},
			item: "swordSilver"
		},
		{
			name: "Picareta de Prata",
			level: 28,
			seconds: 11,
			xp: 130,
			cost: {
				barSilver: 4,
				birch: 2
			},
			item: "pickSilver"
		},
		{
			name: "Cota de Prata",
			level: 32,
			seconds: 13,
			xp: 150,
			cost: { barSilver: 8 },
			item: "armorSilver"
		},
		{
			name: "Lâmina de Cinzálio",
			level: 55,
			seconds: 16,
			xp: 260,
			cost: {
				oreAsh: 12,
				crystal: 5
			},
			item: "swordAsh"
		},
		{
			name: "Placas de Cinzálio",
			level: 62,
			seconds: 18,
			xp: 300,
			cost: {
				oreAsh: 10,
				barSilver: 4
			},
			item: "armorAsh"
		}
	],
	alchemy: [
		{
			name: "Poção de Vida",
			level: 1,
			seconds: 5,
			xp: 25,
			cost: {
				wood: 2,
				oreCopper: 1
			},
			item: "potion"
		},
		{
			name: "Elixir Arcano",
			level: 15,
			seconds: 7,
			xp: 48,
			cost: {
				crystal: 2,
				oreSilver: 1
			},
			item: "elixir"
		},
		{
			name: "Tônico de Enguia",
			level: 32,
			seconds: 8,
			xp: 110,
			cost: {
				eel: 1,
				crystal: 1
			},
			item: "tonic"
		},
		{
			name: "Frasco do Abismo",
			level: 55,
			seconds: 10,
			xp: 230,
			cost: {
				abyssfish: 1,
				oreAsh: 1,
				crystal: 1
			},
			item: "vial"
		}
	],
	craft: [
		{
			name: "Arco Simples",
			level: 1,
			seconds: 5,
			xp: 25,
			cost: { wood: 5 },
			item: "bow"
		},
		{
			name: "Arco de Bétula",
			level: 14,
			seconds: 7,
			xp: 55,
			cost: {
				birch: 6,
				wood: 2
			},
			item: "bowBirch"
		},
		{
			name: "Capa Sombria",
			level: 20,
			seconds: 8,
			xp: 60,
			cost: {
				darkwood: 5,
				birch: 3
			},
			item: "cape"
		},
		{
			name: "Couraça Ancestral",
			level: 40,
			seconds: 12,
			xp: 160,
			cost: {
				elderwood: 8,
				birch: 4
			},
			item: "armorElder"
		},
		{
			name: "Arco Ancestral",
			level: 48,
			seconds: 12,
			xp: 190,
			cost: {
				elderwood: 6,
				darkwood: 2,
				crystal: 1
			},
			item: "bowElder"
		},
		{
			name: "Manto Ancestral",
			level: 52,
			seconds: 12,
			xp: 200,
			cost: {
				elderwood: 5,
				darkwood: 4,
				gem: 1
			},
			item: "capeElder"
		}
	]
};
var mat = (name) => ({
	name,
	kind: "material"
});
var gear = (name) => ({
	name,
	kind: "gear"
});
var food = (name) => ({
	name,
	kind: "food"
});
var items = {
	oreCopper: mat("Minério de Cobre"),
	oreIron: mat("Minério de Ferro"),
	oreSilver: mat("Minério de Prata"),
	crystal: mat("Cristal Arcano"),
	oreAsh: mat("Cinzálio"),
	wood: mat("Madeira Retorcida"),
	birch: mat("Bétula Pálida"),
	darkwood: mat("Madeira Sombria"),
	elderwood: mat("Madeira Ancestral"),
	fish: mat("Peixe do Riacho"),
	trout: mat("Truta"),
	eel: mat("Enguia"),
	abyssfish: mat("Peixe Abissal"),
	food: food("Peixe Assado"),
	foodBig: food("Truta Defumada"),
	foodEel: food("Ensopado de Enguia"),
	foodAbyss: food("Banquete Abissal"),
	barCopper: mat("Barra de Cobre"),
	barIron: mat("Barra de Ferro"),
	barSilver: mat("Barra de Prata"),
	swordCopper: gear("Espada de Cobre"),
	swordIron: gear("Espada de Ferro"),
	swordSilver: gear("Lâmina de Prata"),
	swordAsh: gear("Lâmina de Cinzálio"),
	pickCopper: gear("Picareta de Cobre"),
	pickIron: gear("Picareta de Ferro"),
	pickSilver: gear("Picareta de Prata"),
	armorIron: gear("Armadura de Ferro"),
	armorSilver: gear("Cota de Prata"),
	armorElder: gear("Couraça Ancestral"),
	armorAsh: gear("Placas de Cinzálio"),
	potion: food("Poção de Vida"),
	elixir: food("Elixir Arcano"),
	tonic: food("Tônico de Enguia"),
	vial: food("Frasco do Abismo"),
	bow: gear("Arco Simples"),
	bowBirch: gear("Arco de Bétula"),
	bowElder: gear("Arco Ancestral"),
	cape: gear("Capa Sombria"),
	capeElder: gear("Manto Ancestral"),
	bone: mat("Osso Antigo"),
	fang: mat("Presa"),
	ash: mat("Essência de Cinzas"),
	gem: mat("Gema Rara"),
	bogEssence: mat("Essência do Pântano"),
	venom: mat("Veneno Concentrado"),
	duskShard: mat("Fragmento Crepuscular"),
	voidCore: mat("Núcleo do Vazio")
};
var gearStats = {
	swordCopper: {
		slot: "weapon",
		atk: 15,
		label: "+15 de ataque"
	},
	bow: {
		slot: "weapon",
		atk: 12,
		label: "+12 de ataque"
	},
	swordIron: {
		slot: "weapon",
		atk: 32,
		label: "+32 de ataque"
	},
	bowBirch: {
		slot: "weapon",
		atk: 26,
		label: "+26 de ataque"
	},
	swordSilver: {
		slot: "weapon",
		atk: 55,
		label: "+55 de ataque"
	},
	bowElder: {
		slot: "weapon",
		atk: 72,
		label: "+72 de ataque"
	},
	swordAsh: {
		slot: "weapon",
		atk: 100,
		label: "+100 de ataque"
	},
	armorIron: {
		slot: "armor",
		def: 28,
		label: "+28 de defesa"
	},
	armorSilver: {
		slot: "armor",
		def: 46,
		label: "+46 de defesa"
	},
	armorElder: {
		slot: "armor",
		def: 52,
		label: "+52 de defesa"
	},
	armorAsh: {
		slot: "armor",
		def: 84,
		label: "+84 de defesa"
	},
	pickCopper: {
		slot: "tool",
		mine: .8,
		label: "Mineração 20% mais rápida"
	},
	pickIron: {
		slot: "tool",
		mine: .68,
		label: "Mineração 32% mais rápida"
	},
	pickSilver: {
		slot: "tool",
		mine: .55,
		label: "Mineração 45% mais rápida"
	},
	cape: {
		slot: "accessory",
		def: 6,
		label: "+6 de defesa"
	},
	capeElder: {
		slot: "accessory",
		def: 14,
		mag: 18,
		label: "+14 de defesa e +18 de magia"
	}
};
var foods = {
	food: 35,
	foodBig: 80,
	potion: 90,
	foodEel: 150,
	elixir: 180,
	tonic: 240,
	foodAbyss: 280,
	vial: 360
};
function itemBlurb(id) {
	if (foods[id]) return `Recupera ${foods[id]} de vida.`;
	return gearStats[id]?.label || "";
}
var zones = [
	{
		name: "Campos das Brasas",
		level: 1,
		cost: 0,
		monsters: [
			{
				name: "Rato Corrompido",
				level: 1,
				hp: 35,
				atk: 7,
				gold: 12,
				loot: "fang"
			},
			{
				name: "Bandido Desgarrado",
				level: 4,
				hp: 60,
				atk: 11,
				gold: 21,
				loot: "bone"
			},
			{
				name: "Lobo Cinzento",
				level: 8,
				hp: 100,
				atk: 16,
				gold: 32,
				loot: "fang"
			},
			{
				name: "Chefe: Saqueador",
				level: 12,
				hp: 220,
				atk: 23,
				gold: 75,
				loot: "gem"
			}
		]
	},
	{
		name: "Floresta dos Lamentos",
		level: 14,
		cost: 400,
		monsters: [
			{
				name: "Aranha de Névoa",
				level: 14,
				hp: 160,
				atk: 22,
				gold: 45,
				loot: "fang"
			},
			{
				name: "Guardião de Musgo",
				level: 20,
				hp: 250,
				atk: 28,
				gold: 65,
				loot: "wood"
			},
			{
				name: "Espectro Faminto",
				level: 27,
				hp: 360,
				atk: 36,
				gold: 92,
				loot: "ash"
			},
			{
				name: "Chefe: Rei dos Espinhos",
				level: 35,
				hp: 650,
				atk: 49,
				gold: 180,
				loot: "gem"
			}
		]
	},
	{
		name: "Cripta do Eclipse",
		level: 35,
		cost: 3e3,
		monsters: [
			{
				name: "Esqueleto Guerreiro",
				level: 35,
				hp: 500,
				atk: 49,
				gold: 125,
				loot: "bone"
			},
			{
				name: "Cavaleiro Esquecido",
				level: 43,
				hp: 720,
				atk: 65,
				gold: 180,
				loot: "barIron"
			},
			{
				name: "Bruxa das Cinzas",
				level: 52,
				hp: 940,
				atk: 82,
				gold: 260,
				loot: "crystal"
			},
			{
				name: "Chefe: Vigia do Eclipse",
				level: 62,
				hp: 1600,
				atk: 112,
				gold: 600,
				loot: "gem"
			}
		]
	},
	{
		name: "Abismo Carmesim",
		level: 65,
		cost: 18e3,
		monsters: [
			{
				name: "Demônio das Brasas",
				level: 65,
				hp: 1450,
				atk: 120,
				gold: 390,
				loot: "ash"
			},
			{
				name: "Draco Vulcânico",
				level: 75,
				hp: 2400,
				atk: 170,
				gold: 700,
				loot: "gem"
			},
			{
				name: "Chefe: Coração da Ruína",
				level: 90,
				hp: 4500,
				atk: 230,
				gold: 1600,
				loot: "gem"
			}
		]
	},
	{
		name: "Pântano dos Ecos",
		level: 95,
		cost: 42e3,
		monsters: [
			{
				name: "Lodo Devorador",
				level: 95,
				hp: 5200,
				atk: 245,
				gold: 1900,
				loot: "bogEssence"
			},
			{
				name: "Caçador Afogado",
				level: 102,
				hp: 6800,
				atk: 285,
				gold: 2300,
				loot: "bogEssence"
			},
			{
				name: "Serpente Venenosa",
				level: 110,
				hp: 8200,
				atk: 320,
				gold: 2800,
				loot: "venom"
			},
			{
				name: "Chefe: Mãe do Lodo",
				level: 120,
				hp: 15e3,
				atk: 390,
				gold: 6500,
				loot: "bogEssence"
			}
		]
	},
	{
		name: "Cidadela do Crepúsculo",
		level: 125,
		cost: 95e3,
		monsters: [
			{
				name: "Sentinela Crepuscular",
				level: 125,
				hp: 16e3,
				atk: 420,
				gold: 4200,
				loot: "duskShard"
			},
			{
				name: "Lâmina Espectral",
				level: 135,
				hp: 19e3,
				atk: 465,
				gold: 5e3,
				loot: "duskShard"
			},
			{
				name: "Arauto do Vazio",
				level: 145,
				hp: 24e3,
				atk: 520,
				gold: 6200,
				loot: "voidCore"
			},
			{
				name: "Chefe: Regente Sem Sol",
				level: 160,
				hp: 42e3,
				atk: 650,
				gold: 15e3,
				loot: "voidCore"
			}
		]
	}
];
var stalls = {
	pedro: {
		name: "Pedro",
		role: "Suprimentos de expedição",
		sell: .62,
		line: "O que a trilha ainda deixa passar, eu tenho. Ouro na mesa, mercadoria na mochila.",
		goods: [
			{
				id: "oreCopper",
				price: 4
			},
			{
				id: "oreIron",
				price: 14
			},
			{
				id: "oreSilver",
				price: 22
			},
			{
				id: "wood",
				price: 3
			},
			{
				id: "birch",
				price: 9
			},
			{
				id: "darkwood",
				price: 28
			},
			{
				id: "elderwood",
				price: 70
			},
			{
				id: "fish",
				price: 5
			},
			{
				id: "trout",
				price: 16
			},
			{
				id: "eel",
				price: 26
			},
			{
				id: "abyssfish",
				price: 80
			},
			{
				id: "food",
				price: 9
			},
			{
				id: "bone",
				price: 8
			},
			{
				id: "fang",
				price: 8
			}
		]
	},
	luan: {
		name: "Luan",
		role: "Bancada do artesão",
		sell: .74,
		line: "Barras, frascos e o que brilha. Eu pago melhor pelo que você mesmo faz.",
		goods: [
			{
				id: "barCopper",
				price: 18
			},
			{
				id: "barIron",
				price: 42
			},
			{
				id: "barSilver",
				price: 78
			},
			{
				id: "potion",
				price: 22
			},
			{
				id: "elixir",
				price: 70
			},
			{
				id: "tonic",
				price: 95
			},
			{
				id: "vial",
				price: 160
			},
			{
				id: "foodBig",
				price: 24
			},
			{
				id: "foodEel",
				price: 48
			},
			{
				id: "foodAbyss",
				price: 110
			},
			{
				id: "crystal",
				price: 55
			},
			{
				id: "gem",
				price: 35
			},
			{
				id: "oreAsh",
				price: 90
			},
			{
				id: "bogEssence",
				price: 85
			},
			{
				id: "venom",
				price: 65
			},
			{
				id: "duskShard",
				price: 140
			},
			{
				id: "voidCore",
				price: 320
			}
		]
	}
};
var skillIcons = {
	attack: "sword",
	strength: "axe",
	defense: "shield",
	ranged: "bow",
	magic: "orb",
	wood: "axe",
	mining: "pick",
	fishing: "rod",
	cooking: "pot",
	smithing: "anvil",
	alchemy: "flask",
	craft: "thread"
};
function skillIcon(id) {
	return `/pixel/ico-${skillIcons[id]}.png`;
}
function itemIcon(id) {
	if (id === "gold") return "/pixel/ico-coins.png";
	if (items[id]) return `/pixel/items/${id}.png`;
	return "/pixel/ico-ore.png";
}
function monsterSrc(name) {
	const n = name.toLowerCase();
	if (n.includes("aranha")) return "/pixel/mon-spider.png";
	if (n.includes("lobo")) return "/pixel/mon-wolf.png";
	if (n.includes("rato")) return "/pixel/mon-rat.png";
	if (n.includes("lodo") || n.includes("serpente") || n.includes("mãe") || n.includes("afogado")) return "/pixel/mon-slime.png";
	if (n.includes("draco") || n.includes("demônio") || n.includes("coração")) return "/pixel/mon-drake.png";
	if (n.includes("espectro") || n.includes("bruxa") || n.includes("vazio") || n.includes("regente") || n.includes("vigia") || n.includes("araute") || n.includes("lâmina") || n.includes("crepusc")) return "/pixel/mon-wraith.png";
	return "/pixel/mon-skeleton.png";
}
function sceneForSkill(id) {
	return {
		mining: "/pixel/scene-mine.jpg",
		wood: "/pixel/scene-wood.jpg",
		fishing: "/pixel/scene-fish.jpg",
		smithing: "/pixel/scene-forge.jpg",
		cooking: "/pixel/scene-hearth.jpg",
		alchemy: "/pixel/scene-lab.jpg",
		craft: "/pixel/scene-home.jpg"
	}[id] || "/pixel/scene-combat.jpg";
}
function heroPose(id, combat = false) {
	if (combat) return "/pixel/hero-fight.png";
	return id && {
		mining: "/pixel/hero-mine.png",
		wood: "/pixel/hero-wood.png",
		fishing: "/pixel/hero-fish.png",
		smithing: "/pixel/hero-forge.png",
		cooking: "/pixel/hero-cook.png",
		alchemy: "/pixel/hero-flask.png",
		craft: "/pixel/hero-forge.png",
		attack: "/pixel/hero-fight.png",
		strength: "/pixel/hero-fight.png",
		defense: "/pixel/hero-fight.png",
		ranged: "/pixel/hero-fight.png",
		magic: "/pixel/hero-flask.png"
	}[id] || "/pixel/hero-idle.png";
}
var zoneScenes = [
	"/pixel/scene-combat.jpg",
	"/pixel/scene-wood.jpg",
	"/pixel/scene-crypt.jpg",
	"/pixel/scene-abyss.jpg",
	"/pixel/scene-swamp.jpg",
	"/pixel/scene-citadel.jpg"
];
var petArt = {
	mossling: "/pixel/pet-moss.png",
	emberfox: "/pixel/pet-fox.png",
	stonecub: "/pixel/pet-cub.png",
	nightowl: "/pixel/pet-owl.png"
};
var workerJobs = {
	mining: {
		name: "Mineração",
		xp: "mining",
		tiers: [
			{
				name: "Cobre",
				level: 1,
				resource: "oreCopper",
				interval: 9,
				base: 1,
				xp: 4
			},
			{
				name: "Ferro",
				level: 8,
				resource: "oreIron",
				interval: 12,
				base: 1,
				xp: 8
			},
			{
				name: "Prata",
				level: 18,
				resource: "oreSilver",
				interval: 16,
				base: 1,
				xp: 14
			},
			{
				name: "Cristal",
				level: 35,
				resource: "crystal",
				interval: 22,
				base: 1,
				xp: 22
			},
			{
				name: "Cinzálio",
				level: 55,
				resource: "oreAsh",
				interval: 28,
				base: 1,
				xp: 36
			}
		]
	},
	wood: {
		name: "Corte de lenha",
		xp: "wood",
		tiers: [
			{
				name: "Retorcida",
				level: 1,
				resource: "wood",
				interval: 8,
				base: 1,
				xp: 4
			},
			{
				name: "Bétula",
				level: 12,
				resource: "birch",
				interval: 11,
				base: 1,
				xp: 8
			},
			{
				name: "Sombria",
				level: 30,
				resource: "darkwood",
				interval: 15,
				base: 1,
				xp: 16
			},
			{
				name: "Ancestral",
				level: 55,
				resource: "elderwood",
				interval: 20,
				base: 1,
				xp: 30
			}
		]
	},
	fishing: {
		name: "Pesca",
		xp: "fishing",
		tiers: [
			{
				name: "Riacho",
				level: 1,
				resource: "fish",
				interval: 11,
				base: 1,
				xp: 4
			},
			{
				name: "Truta",
				level: 12,
				resource: "trout",
				interval: 14,
				base: 1,
				xp: 9
			},
			{
				name: "Enguia",
				level: 30,
				resource: "eel",
				interval: 18,
				base: 1,
				xp: 16
			},
			{
				name: "Abismo",
				level: 55,
				resource: "abyssfish",
				interval: 24,
				base: 1,
				xp: 32
			}
		]
	},
	smithing: {
		name: "Metalurgia",
		xp: "smithing",
		tiers: [
			{
				name: "Cobre",
				level: 1,
				resource: "barCopper",
				interval: 18,
				base: 1,
				xp: 6,
				cost: { oreCopper: 3 }
			},
			{
				name: "Ferro",
				level: 8,
				resource: "barIron",
				interval: 22,
				base: 1,
				xp: 12,
				cost: { oreIron: 3 }
			},
			{
				name: "Prata",
				level: 18,
				resource: "barSilver",
				interval: 26,
				base: 1,
				xp: 18,
				cost: { oreSilver: 3 }
			}
		]
	},
	cooking: {
		name: "Culinária",
		xp: "cooking",
		tiers: [
			{
				name: "Assado",
				level: 1,
				resource: "food",
				interval: 16,
				base: 1,
				xp: 5,
				cost: { fish: 2 }
			},
			{
				name: "Defumado",
				level: 12,
				resource: "foodBig",
				interval: 20,
				base: 1,
				xp: 10,
				cost: { trout: 2 }
			},
			{
				name: "Ensopado",
				level: 30,
				resource: "foodEel",
				interval: 24,
				base: 1,
				xp: 16,
				cost: { eel: 2 }
			}
		]
	}
};
var workerNames = [
	"Borin",
	"Mira",
	"Tomas",
	"Edda",
	"Rurik",
	"Lysa",
	"Darian",
	"Nessa",
	"Oren",
	"Syla"
];
var hireCosts = [
	180,
	420,
	900,
	1800,
	3600,
	7200
];
var propertyDefs = {
	house: {
		name: "Casa do Aventureiro",
		desc: "Um lar seguro. Aumenta o espaço de armazenamento.",
		cost: {
			wood: 35,
			oreCopper: 12
		},
		max: 5
	},
	warehouse: {
		name: "Depósito",
		desc: "Amplia bastante a capacidade de materiais.",
		cost: {
			wood: 45,
			oreCopper: 18
		},
		max: 8
	},
	workshop: {
		name: "Oficina",
		desc: "Metalúrgicos e cozinheiros contratados produzem +1 por ciclo.",
		cost: {
			wood: 30,
			barCopper: 8
		},
		max: 5
	},
	garden: {
		name: "Horta",
		desc: "Gera comida periodicamente enquanto o vale segue desperto.",
		cost: {
			wood: 25,
			fish: 4
		},
		max: 5
	}
};
var petDefs = [
	{
		id: "mossling",
		name: "Musguinho",
		cost: 260,
		bonus: "gather",
		desc: "+1 recurso por ciclo de coleta e de servo."
	},
	{
		id: "emberfox",
		name: "Raposa Ígnea",
		cost: 520,
		bonus: "xp",
		desc: "+12% de experiência em todas as perícias."
	},
	{
		id: "stonecub",
		name: "Filhote de Pedra",
		cost: 850,
		bonus: "def",
		desc: "Reduz o dano recebido em combate em 8%."
	},
	{
		id: "nightowl",
		name: "Coruja Noturna",
		cost: 1200,
		bonus: "offline",
		desc: "+2 horas no limite de progresso offline."
	}
];
var contractPool = [
	{
		id: "slay5",
		title: "Ameaça nas estradas",
		desc: "Derrote 5 monstros.",
		type: "kills",
		goal: 5,
		gold: 180,
		xp: 90
	},
	{
		id: "slay12",
		title: "Caçador incansável",
		desc: "Derrote 12 monstros.",
		type: "kills",
		goal: 12,
		gold: 420,
		xp: 220
	},
	{
		id: "skill25",
		title: "Mãos laboriosas",
		desc: "Conclua 25 ações de perícia.",
		type: "actions",
		goal: 25,
		gold: 160,
		xp: 110
	},
	{
		id: "skill60",
		title: "Ofício aperfeiçoado",
		desc: "Conclua 60 ações de perícia.",
		type: "actions",
		goal: 60,
		gold: 360,
		xp: 240
	},
	{
		id: "servant20",
		title: "Uma equipe produtiva",
		desc: "Seus servos devem concluir 20 tarefas.",
		type: "workers",
		goal: 20,
		gold: 300,
		xp: 160
	}
];
var listeners = /* @__PURE__ */ new Set();
var rev = 0;
var quiet = false;
var toastTimer = 0;
var booted = false;
function blankLevels() {
	return Object.fromEntries(skills.map((s) => [s.id, { xp: 0 }]));
}
function initial() {
	return {
		gold: 125,
		hp: 128,
		maxhp: 128,
		inventory: {
			wood: 4,
			fish: 3,
			oreCopper: 3,
			food: 2
		},
		levels: blankLevels(),
		equip: {
			weapon: null,
			armor: null,
			tool: null,
			accessory: null
		},
		unlocked: [0],
		action: null,
		progress: 0,
		last: Date.now(),
		kills: 0,
		achievements: [],
		autoFood: true,
		autoCombat: false,
		style: "attack",
		battle: null,
		turn: 0,
		stats: {
			actions: 0,
			crafted: 0,
			workerActions: 0
		},
		workers: [],
		workerClock: 0,
		property: {
			house: 0,
			warehouse: 0,
			workshop: 0,
			garden: 0
		},
		pets: [],
		activePet: null,
		contractDay: "",
		contractCounts: {
			kills: 0,
			actions: 0,
			workers: 0
		},
		contractClaimed: [],
		dailyContracts: [],
		gardenClock: 0,
		log: []
	};
}
var save = initial();
var ui = {
	tab: "home",
	selected: "mining",
	toast: "",
	confirmReset: false,
	pulse: "",
	pulseN: 0,
	splash: null
};
function emit() {
	rev += 1;
	listeners.forEach((l) => l());
}
function subscribe(l) {
	listeners.add(l);
	return () => listeners.delete(l);
}
function getRev() {
	return rev;
}
function getSave() {
	return save;
}
function getUI() {
	return ui;
}
function num(n) {
	if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
	if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
	return Math.floor(n).toLocaleString("pt-BR");
}
function lvl(id) {
	return Math.max(1, Math.floor(Math.sqrt((save.levels[id]?.xp || 0) / 35)) + 1);
}
function need(id) {
	return 35 * lvl(id) * lvl(id);
}
function pct(id) {
	const lv = lvl(id);
	return ((save.levels[id]?.xp || 0) - 35 * (lv - 1) ** 2) / (35 * (2 * lv - 1)) * 100;
}
function totalLevel() {
	return skills.reduce((n, s) => n + lvl(s.id), 0);
}
function inv(id) {
	return save.inventory[id] || 0;
}
function storageCapacity() {
	return 120 + (save.property.warehouse || 0) * 180 + (save.property.house || 0) * 30;
}
function usedStorage() {
	return Object.values(save.inventory).reduce((a, b) => a + Math.max(0, b), 0);
}
function activeBonus() {
	return save.pets.find((p) => p.id === save.activePet)?.bonus ?? null;
}
function notify(msg) {
	if (quiet) return;
	ui.toast = msg;
	emit();
	window.clearTimeout(toastTimer);
	toastTimer = window.setTimeout(() => {
		ui.toast = "";
		emit();
	}, 2600);
}
function note(k, text) {
	if (quiet) return;
	save.log = [{
		k,
		text
	}, ...save.log || []].slice(0, 14);
}
function mark(text, splash) {
	if (quiet) return;
	ui.pulse = text;
	ui.pulseN += 1;
	if (splash) ui.splash = {
		...splash,
		n: ui.pulseN
	};
}
function saveNow() {
	save.last = Date.now();
	try {
		localStorage.setItem(SAVE_KEY, JSON.stringify(save));
	} catch {}
}
function commit() {
	saveNow();
	emit();
}
function add(id, n = 1) {
	if (n <= 0 || id === "gold") {
		save.inventory[id] = Math.max(0, inv(id) + n);
		return true;
	}
	const room = Math.max(0, storageCapacity() - usedStorage());
	if (room <= 0) return false;
	const give = Math.min(n, room);
	save.inventory[id] = inv(id) + give;
	return give === n;
}
function spend(cost) {
	if (!Object.entries(cost).every(([k, v]) => inv(k) >= v)) return false;
	Object.entries(cost).forEach(([k, v]) => add(k, -v));
	return true;
}
function gain(id, xp) {
	if (activeBonus() === "xp") xp = Math.ceil(xp * 1.12);
	const old = lvl(id);
	if (!save.levels[id]) save.levels[id] = { xp: 0 };
	save.levels[id].xp += xp;
	if (lvl(id) > old) notify(`${skills.find((s) => s.id === id)?.name} nível ${lvl(id)}`);
}
function costText(cost) {
	return Object.entries(cost).map(([k, v]) => `${v} ${items[k]?.name || k} (${inv(k)})`).join(" · ");
}
function playerStats() {
	const w = gearStats[save.equip.weapon || ""] || {};
	const ar = gearStats[save.equip.armor || ""] || {};
	const ac = gearStats[save.equip.accessory || ""] || {};
	return {
		atk: 8 + lvl("attack") * 2 + lvl("strength") * 2 + (w.atk || 0),
		def: 3 + lvl("defense") * 2 + (ar.def || 0) + (ac.def || 0),
		max: 120 + lvl("defense") * 8,
		magic: 4 + lvl("magic") * 2 + (w.mag || 0) + (ac.mag || 0)
	};
}
function speedMult(skill) {
	if (skill !== "mining") return 1;
	return gearStats[save.equip.tool || ""]?.mine ?? 1;
}
function fmtDur(sec) {
	if (!Number.isFinite(sec) || sec < 0) return "—";
	if (sec >= 3600) return `${Math.floor(sec / 3600)}h ${Math.floor(sec % 3600 / 60).toString().padStart(2, "0")}m`;
	if (sec >= 60) return `${Math.floor(sec / 60)}m ${Math.floor(sec % 60).toString().padStart(2, "0")}s`;
	return `${sec.toFixed(1).replace(".", ",")}s`;
}
function actionClock() {
	const a = save.action;
	if (!a) return null;
	const total = a.type === "combat" ? 2.4 : (listFor(a.skill)?.[a.index]?.seconds || 3) * speedMult(a.skill);
	return {
		total,
		left: Math.max(0, total * (1 - Math.min(.999, save.progress)))
	};
}
function levelEta(skill) {
	const a = save.action;
	if (!a || a.type !== "skill" || a.skill !== skill) return null;
	const row = listFor(skill)?.[a.index];
	const clock = actionClock();
	if (!row || !clock) return null;
	const xp = activeBonus() === "xp" ? row.xp * 1.12 : row.xp;
	const leftXp = Math.max(0, need(skill) - (save.levels[skill]?.xp || 0));
	if (xp <= 0) return null;
	return leftXp / xp * clock.total;
}
function listFor(skill) {
	return nodes[skill] || recipes[skill] || null;
}
function stop() {
	save.action = null;
	save.battle = null;
	save.progress = 0;
	commit();
}
function startSkill(skill, index) {
	const row = listFor(skill)?.[index];
	if (!row || lvl(skill) < row.level) return notify("Nível insuficiente.");
	save.action = {
		type: "skill",
		skill,
		index
	};
	save.progress = 0;
	commit();
}
function startCombat(zone, index) {
	if (!save.unlocked.includes(zone)) return notify("Desbloqueie esta região primeiro.");
	const m = zones[zone]?.monsters[index];
	save.action = {
		type: "combat",
		zone,
		index
	};
	save.progress = 0;
	save.battle = null;
	save.turn = 0;
	if (m) note("say", `Você encara ${m.name}.`);
	commit();
}
function win(zone, index) {
	const m = zones[zone]?.monsters[index];
	if (!m) return;
	save.kills += 1;
	save.contractCounts.kills = (save.contractCounts.kills || 0) + 1;
	save.gold += m.gold;
	const qty = 1 + Math.floor(Math.random() * 2);
	const placed = add(m.loot, qty);
	if (Math.random() < .08) add("gem");
	save.battle = null;
	save.turn = 0;
	save.hp = Math.min(save.maxhp, save.hp + Math.floor(save.maxhp * .12));
	const loot = items[m.loot]?.name || m.loot;
	note("win", placed ? `${m.name} cai. +${m.gold} ouro e ${loot}.` : `${m.name} cai. +${m.gold} ouro. O depósito não coube o saque.`);
	mark(`+${m.gold} ouro`, {
		text: `+${m.gold}`,
		k: "loot"
	});
	if (!save.autoCombat) {
		save.action = null;
		notify(`Vitória. +${m.gold} ouro`);
	}
	if (m.name.startsWith("Chefe")) notify(`${m.name} derrotado`);
}
var eatOrder = Object.entries(foods).map(([id, heal]) => ({
	id,
	heal
})).sort((a, b) => a.heal - b.heal);
function eatSmart() {
	if (!save.autoFood) return;
	const ratio = save.hp / Math.max(1, save.maxhp);
	if (ratio >= .62) return;
	const have = eatOrder.filter((f) => inv(f.id) > 0);
	if (!have.length) return;
	const missing = save.maxhp - save.hp;
	const pick = ratio < .32 ? have[have.length - 1] : have.find((f) => f.heal >= missing * .65) || have[0];
	add(pick.id, -1);
	const before = save.hp;
	save.hp = Math.min(save.maxhp, save.hp + pick.heal);
	const gained = save.hp - before;
	note("eat", `Você usa ${items[pick.id]?.name || pick.id} e recupera ${gained}.`);
}
function combatTurn(zone, index) {
	const m = zones[zone]?.monsters[index];
	if (!m) return;
	const p = playerStats();
	save.maxhp = p.max;
	save.hp = Math.min(save.hp, save.maxhp);
	if (!save.battle) save.battle = {
		hp: m.hp,
		guard: false
	};
	const b = save.battle;
	if (b.hp <= 0) {
		win(zone, index);
		return;
	}
	let dmg = Math.max(1, Math.round(p.atk * (.75 + Math.random() * .45)));
	if (save.style === "magic") {
		dmg = Math.round(dmg * .5 + p.magic * 1.6);
		gain("magic", m.level + 4);
	} else if (save.style === "ranged") {
		dmg = Math.round(dmg * .9);
		gain("ranged", m.level + 4);
	} else gain("attack", m.level + 4);
	b.hp -= dmg;
	gain("strength", Math.ceil(m.level / 2));
	note("hit", `${save.style === "magic" ? "O feitiço acerta" : save.style === "ranged" ? "A flecha acerta" : "Você acerta"} ${m.name} e tira ${dmg}.`);
	mark(`−${dmg}`, {
		text: `−${dmg}`,
		k: "foe"
	});
	if (b.hp <= 0) {
		win(zone, index);
		return;
	}
	let incoming = Math.max(1, Math.round(m.atk * (.7 + Math.random() * .6) - p.def * .42));
	if (activeBonus() === "def") incoming = Math.ceil(incoming * .92);
	save.hp = Math.max(0, save.hp - incoming);
	gain("defense", Math.ceil(m.level / 3));
	note("hurt", `${m.name} devolve ${incoming}.`);
	save.turn += 1;
	eatSmart();
	if (save.hp <= 0) {
		save.hp = save.maxhp;
		save.gold = Math.max(0, save.gold - Math.ceil(save.gold * .04));
		save.battle = null;
		save.action = null;
		note("lose", "Você cai. A trilha toma 4% do ouro.");
		notify("Derrota. Você perdeu 4% do ouro.");
	}
}
function fullStop(msg) {
	save.action = null;
	save.progress = 0;
	notify(msg);
}
function tickAction() {
	const a = save.action;
	if (!a) return;
	save.stats.actions += 1;
	save.contractCounts.actions = (save.contractCounts.actions || 0) + 1;
	if (a.type === "skill") {
		const row = listFor(a.skill)?.[a.index];
		if (!row || lvl(a.skill) < row.level) {
			save.action = null;
			save.progress = 0;
			return;
		}
		if (nodes[a.skill]) {
			if (!add(row.item)) return fullStop("O depósito encheu. A coleta parou.");
			gain(a.skill, row.xp);
			let extra = "";
			if (Math.random() < .012 && add("gem")) extra += " · gema";
			if (a.skill === "mining" && Math.random() < .05 && add("crystal")) extra += " · cristal";
			mark(`+1 ${items[row.item]?.name || row.item}${extra}`, {
				text: "+1",
				k: "loot"
			});
		} else {
			const recipe = recipes[a.skill]?.[a.index];
			if (!recipe || !spend(recipe.cost)) {
				save.action = null;
				save.progress = 0;
				notify("Faltam materiais.");
				return;
			}
			if (!add(recipe.item)) {
				Object.entries(recipe.cost).forEach(([k, v]) => add(k, v));
				return fullStop("O depósito encheu. O ofício parou.");
			}
			gain(a.skill, recipe.xp);
			save.stats.crafted += 1;
			mark(`+1 ${items[recipe.item]?.name || recipe.item}`, {
				text: "+1",
				k: "loot"
			});
		}
	} else combatTurn(a.zone, a.index);
}
function workerPlan(w) {
	const job = workerJobs[w.job] || workerJobs.mining;
	const open = job.tiers.map((tier, index) => ({
		tier,
		index
	})).filter(({ tier }) => lvl(job.xp) >= tier.level);
	const pool = open.length ? open : [{
		tier: job.tiers[0],
		index: 0
	}];
	const chosen = (w.tier != null && w.tier >= 0 ? pool.find((x) => x.index === w.tier) : void 0) || pool[pool.length - 1];
	return {
		job,
		tier: chosen.tier,
		index: chosen.index
	};
}
function workerTick(sec) {
	if (!save.workers.length) return;
	save.workerClock = (save.workerClock || 0) + sec;
	for (const w of save.workers) {
		if (!w.active) continue;
		const plan = workerPlan(w);
		const tier = plan.tier;
		w.progress = (w.progress || 0) + sec;
		while (w.progress >= tier.interval) {
			if (tier.cost && !spend(tier.cost)) {
				w.active = false;
				notify(`${w.name} pausou: faltam materiais para ${tier.name.toLowerCase()}.`);
				break;
			}
			const wage = 1 + Math.floor((w.level - 1) / 3);
			if (save.gold < wage) {
				if (tier.cost) Object.entries(tier.cost).forEach(([k, v]) => add(k, v));
				w.active = false;
				notify(`${w.name} parou: falta ouro para o salário.`);
				break;
			}
			const amount = tier.base + Math.floor((w.level - 1) / 4) + (activeBonus() === "gather" ? 1 : 0) + (save.property.workshop > 0 && (w.job === "smithing" || w.job === "cooking") ? 1 : 0);
			w.progress -= tier.interval;
			save.gold -= wage;
			if (!add(tier.resource, amount)) {
				save.gold += wage;
				if (tier.cost) Object.entries(tier.cost).forEach(([k, v]) => add(k, v));
				w.active = false;
				notify(`${w.name} parou: o depósito está cheio.`);
				break;
			}
			gain(plan.job.xp, tier.xp + Math.floor(w.level / 2));
			w.xp = (w.xp || 0) + 5;
			const old = w.level;
			w.level = Math.min(30, Math.floor(Math.sqrt(w.xp / 45)) + 1);
			if (w.level > old) notify(`${w.name} evoluiu para o nível ${w.level}`);
			save.stats.workerActions = (save.stats.workerActions || 0) + 1;
			save.stats.actions += 1;
			save.contractCounts.workers = (save.contractCounts.workers || 0) + 1;
		}
	}
}
function gardenTick(sec) {
	const lv = save.property.garden || 0;
	if (lv <= 0) return;
	save.gardenClock = (save.gardenClock || 0) + sec;
	while (save.gardenClock >= 40) {
		save.gardenClock -= 40;
		add("food", lv);
	}
}
function step(sec, offline = false) {
	workerTick(sec);
	gardenTick(sec);
	const a = save.action;
	if (!a) return;
	const row = a.type === "skill" ? listFor(a.skill)?.[a.index] : null;
	const speed = a.type === "combat" ? 2.4 : row?.seconds || 3;
	const bonus = a.type === "skill" ? speedMult(a.skill) : 1;
	save.progress += sec / (speed * bonus);
	const loops = Math.min(Math.floor(save.progress), offline ? 25e3 : 5);
	save.progress -= loops;
	for (let i = 0; i < loops; i += 1) {
		if (!save.action) break;
		tickAction();
	}
}
var uiClock = 0;
function frame(dt) {
	step(dt, false);
	const p = playerStats();
	save.maxhp = p.max;
	save.hp = Math.min(save.hp, save.maxhp);
	uiClock += dt;
	if (uiClock > .2) {
		uiClock = 0;
		emit();
	}
}
function normalize(raw) {
	const base = initial();
	if (!raw || typeof raw !== "object") return base;
	return {
		...base,
		...raw,
		levels: {
			...base.levels,
			...raw.levels || {}
		},
		inventory: { ...raw.inventory || {} },
		equip: {
			...base.equip,
			...raw.equip || {}
		},
		workers: Array.isArray(raw.workers) ? raw.workers : [],
		stats: {
			...base.stats,
			...raw.stats || {}
		},
		property: {
			...base.property,
			...raw.property || {}
		},
		pets: Array.isArray(raw.pets) ? raw.pets : [],
		contractCounts: {
			...base.contractCounts,
			...raw.contractCounts || {}
		},
		contractClaimed: Array.isArray(raw.contractClaimed) ? raw.contractClaimed : [],
		dailyContracts: Array.isArray(raw.dailyContracts) ? raw.dailyContracts : [],
		unlocked: Array.isArray(raw.unlocked) && raw.unlocked.length ? raw.unlocked : [0],
		gardenClock: raw.gardenClock || 0,
		log: cleanLog(raw.log)
	};
}
function cleanLog(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.filter((x) => !!x && typeof x === "object" && typeof x.text === "string" && typeof x.k === "string").slice(0, 14);
}
function ensureContracts() {
	const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	if (save.contractDay === day && save.dailyContracts?.length) return;
	save.contractDay = day;
	save.contractCounts = {
		kills: 0,
		actions: 0,
		workers: 0
	};
	save.contractClaimed = [];
	let list = [
		contractPool[day.charCodeAt(8) % contractPool.length],
		contractPool[(day.charCodeAt(9) + 2) % contractPool.length],
		contractPool[(day.charCodeAt(7) + 4) % contractPool.length]
	].filter((q, i, a) => a.findIndex((x) => x.id === q.id) === i);
	if (list.length < 3) list = [...list, ...contractPool.filter((q) => !list.some((x) => x.id === q.id))].slice(0, 3);
	save.dailyContracts = list;
}
function awayCap() {
	return (8 + (activeBonus() === "offline" ? 2 : 0)) * 3600;
}
function applyAway(announce) {
	const elapsed = Math.max(0, Math.min(awayCap(), (Date.now() - (save.last || Date.now())) / 1e3));
	if (elapsed > 5 && (save.action || save.workers.length || save.property.garden > 0)) {
		const old = save.stats.actions;
		quiet = true;
		step(elapsed, true);
		quiet = false;
		const done = save.stats.actions - old;
		if (announce && done > 0) window.setTimeout(() => notify(`Progresso offline: ${num(done)} ações`), 400);
	}
}
function catchUp() {
	applyAway(true);
	saveNow();
	emit();
}
function boot() {
	if (booted) return;
	booted = true;
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		save = normalize(raw ? JSON.parse(raw) : null);
	} catch {
		save = initial();
	}
	ensureContracts();
	applyAway(true);
	const p = playerStats();
	save.maxhp = p.max;
	if (save.stats.actions === 0 && save.kills === 0) save.hp = p.max;
	else save.hp = Math.min(save.hp || p.max, p.max);
	saveNow();
	emit();
}
function setTab(tab) {
	ui.tab = tab;
	ui.confirmReset = false;
	if (tab === "contracts") ensureContracts();
	emit();
}
function openSkill(id) {
	ui.selected = id;
	ui.tab = "detail";
	emit();
}
function toggleAuto(key) {
	save[key] = !save[key];
	commit();
}
function setStyle(style) {
	save.style = style;
	commit();
}
function unlockZone(z) {
	if (save.gold < zones[z].cost) return notify("Ouro insuficiente.");
	if (z > 0 && !save.unlocked.includes(z - 1)) return notify("Desbloqueie a região anterior.");
	save.gold -= zones[z].cost;
	save.unlocked.push(z);
	commit();
}
function equipItem(id) {
	const stat = gearStats[id];
	if (!stat || !inv(id)) return;
	save.equip[stat.slot] = save.equip[stat.slot] === id ? null : id;
	commit();
}
function useItem(id) {
	const heal = foods[id];
	if (!heal || !inv(id)) return;
	add(id, -1);
	const before = save.hp;
	save.hp = Math.min(save.maxhp, save.hp + heal);
	notify(`+${save.hp - before} HP`);
	commit();
}
function hireWorker(job) {
	const count = save.workers.length;
	if (count >= 6) return notify("Sua propriedade comporta no máximo 6 servos.");
	const cost = hireCosts[Math.min(count, hireCosts.length - 1)];
	if (save.gold < cost) return notify(`Você precisa de ${cost} ouro para contratar.`);
	save.gold -= cost;
	const name = workerNames.find((n) => !save.workers.some((w) => w.name === n)) || `Servo ${count + 1}`;
	save.workers.push({
		id: Date.now() + Math.floor(Math.random() * 1e3),
		name,
		job,
		level: 1,
		xp: 0,
		progress: 0,
		active: true
	});
	notify(`${name} foi contratado`);
	commit();
}
function setWorkerJob(id, job) {
	const w = save.workers.find((x) => x.id === id);
	if (!w || !workerJobs[job]) return;
	w.job = job;
	w.tier = -1;
	w.progress = 0;
	commit();
}
function setWorkerTier(id, tier) {
	const w = save.workers.find((x) => x.id === id);
	if (!w) return;
	w.tier = tier;
	w.progress = 0;
	commit();
}
function toggleWorker(id) {
	const w = save.workers.find((x) => x.id === id);
	if (!w) return;
	w.active = !w.active;
	commit();
}
function build(id) {
	const def = propertyDefs[id];
	const lv = save.property[id] || 0;
	if (lv >= def.max) return notify("Esta construção já atingiu o nível máximo.");
	const cost = {};
	Object.entries(def.cost).forEach(([k, n]) => {
		cost[k] = n * (lv + 1);
	});
	if (!spend(cost)) return notify(`Materiais insuficientes: ${costText(cost)}`);
	save.property[id] = lv + 1;
	notify(`${def.name} aprimorada para o nível ${lv + 1}`);
	commit();
}
function marketTrade(stallId, id, qty, mode) {
	const stall = stalls[stallId];
	const item = stall?.goods.find((x) => x.id === id);
	if (!stall || !item) return;
	qty = Math.max(1, Math.min(99, Math.floor(Number(qty) || 1)));
	const price = item.price * qty;
	if (mode === "buy") {
		if (save.gold < price) return notify("Ouro insuficiente.");
		if (usedStorage() + qty > storageCapacity()) return notify("Seu depósito está cheio.");
		save.gold -= price;
		add(id, qty);
		notify(`Comprou ${qty}× ${items[id]?.name || id}`);
	} else {
		if (inv(id) < qty) return notify("Você não possui essa quantidade.");
		add(id, -qty);
		const earned = Math.floor(price * stall.sell);
		save.gold += earned;
		notify(`Vendeu ${qty}× ${items[id]?.name || id} por ${earned} ouro`);
	}
	commit();
}
function adoptPet(id) {
	const p = petDefs.find((x) => x.id === id);
	if (!p || save.pets.some((x) => x.id === id)) return notify("Você já possui esse mascote.");
	if (save.gold < p.cost) return notify("Ouro insuficiente para adotar esse mascote.");
	save.gold -= p.cost;
	save.pets.push({ ...p });
	if (!save.activePet) save.activePet = id;
	notify(`${p.name} agora é seu companheiro`);
	commit();
}
function setPet(id) {
	save.activePet = save.activePet === id ? null : id;
	commit();
}
function claimContract(id) {
	const q = (save.dailyContracts || []).find((x) => x.id === id);
	if (!q || save.contractClaimed.includes(id)) return;
	if ((save.contractCounts[q.type] || 0) < q.goal) return notify("Contrato ainda não concluído.");
	save.contractClaimed.push(id);
	save.gold += q.gold;
	gain("attack", q.xp);
	add("gem", 1);
	notify(`Contrato concluído. +${q.gold} ouro e uma gema`);
	commit();
}
function exportCode() {
	return btoa(unescape(encodeURIComponent(JSON.stringify(save))));
}
function importCode(raw) {
	try {
		const data = JSON.parse(decodeURIComponent(escape(atob(raw.trim()))));
		if (!data.levels || !data.inventory) throw new Error("bad");
		save = normalize(data);
		ensureContracts();
		commit();
		notify("Save importado");
	} catch {
		notify("Código inválido.");
	}
}
function askReset() {
	ui.confirmReset = true;
	emit();
}
function cancelReset() {
	ui.confirmReset = false;
	emit();
}
function resetGame() {
	localStorage.removeItem(SAVE_KEY);
	save = initial();
	ensureContracts();
	ui.confirmReset = false;
	ui.tab = "home";
	commit();
}
function actionLabel() {
	const a = save.action;
	if (!a) return {
		title: "Nenhuma atividade",
		detail: "Escolha uma perícia ou uma expedição.",
		kind: "Descanso"
	};
	if (a.type === "combat") return {
		title: (zones[a.zone]?.monsters[a.index])?.name || "Combate",
		detail: "Confronto em andamento.",
		kind: "Combate"
	};
	const row = listFor(a.skill)?.[a.index];
	const skill = skills.find((s) => s.id === a.skill);
	return {
		title: row?.name || skill?.name || "Perícia",
		detail: "A produção continua ao navegar.",
		kind: skill?.name || "Perícia"
	};
}
function Ico({ id, alt = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		className: "ico",
		src: itemIcon(id),
		alt
	});
}
function SkillIco({ id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		className: "ico",
		src: skillIcon(id),
		alt: ""
	});
}
function wide(src) {
	return /mine|fish|rat|wolf|drake|spider/.test(src);
}
function Diorama({ scene, pose, foe, label, pet, merchants, splash }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "diorama",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: "bg",
				src: scene,
				alt: ""
			}),
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "stage-label",
				children: label
			}) : null,
			merchants ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: "actor left bob",
				src: "/pixel/pedro.png",
				alt: "Pedro, mercador"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: "actor right flip bob",
				src: "/pixel/luan.png",
				alt: "Luan, mercador"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				pose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: `actor left bob${wide(pose) ? " wide" : ""}`,
					src: pose,
					alt: ""
				}) : null,
				foe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: `actor right foe bob${wide(foe) ? " wide" : ""}`,
					src: foe,
					alt: ""
				}) : null,
				pet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: "pet bob",
					src: pet,
					alt: ""
				}) : null,
				splash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					className: `floater ${splash.k}`,
					children: splash.text
				}, splash.n) : null
			] })
		]
	});
}
function Bar({ value, kind = "xp", label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bar-wrap",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `bar ${kind}`,
			"aria-hidden": true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${Math.max(0, Math.min(100, value))}%` } })
		}), label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "bar-label",
			children: label
		}) : null]
	});
}
function useGame() {
	(0, import_react.useSyncExternalStore)(subscribe, getRev, getRev);
	return {
		S: getSave(),
		ui: getUI()
	};
}
var jobIcon = {
	mining: "/pixel/ico-pick.png",
	wood: "/pixel/ico-axe.png",
	fishing: "/pixel/ico-rod.png",
	smithing: "/pixel/ico-anvil.png",
	cooking: "/pixel/ico-pot.png"
};
var slotName = {
	weapon: "Arma",
	armor: "Armadura",
	tool: "Ferramenta",
	accessory: "Manto"
};
function gearable(id) {
	return Boolean(gearStats[id]);
}
function edible(id) {
	return id in foods;
}
function pace(seconds, xp, skill) {
	const mult = speedMult(skill);
	const pet = getSave().activePet;
	const xpBonus = pet && petDefs.find((p) => p.id === pet)?.bonus === "xp" ? 1.12 : 1;
	const perHour = 3600 / (seconds * mult);
	return `${num(perHour)} ações/h · ${num(perHour * xp * xpBonus)} XP/h · ${fmtDur(seconds * mult)} cada`;
}
function LogList({ lines }) {
	if (!lines.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "tiny",
		children: "Os golpes aparecem aqui, um por turno."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "log",
		children: lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: line.k,
			children: line.text
		}, `${i}-${line.text}`))
	});
}
function visual() {
	const S = getSave();
	const pet = S.activePet ? petArt[S.activePet] : null;
	const a = S.action;
	if (!a) return {
		scene: "/pixel/scene-camp.jpg",
		pose: "/pixel/hero-idle.png",
		foe: void 0,
		label: "Acampamento",
		pet
	};
	if (a.type === "combat") {
		const m = zones[a.zone]?.monsters[a.index];
		return {
			scene: zoneScenes[a.zone] || zoneScenes[0],
			pose: "/pixel/hero-fight.png",
			foe: m ? monsterSrc(m.name) : void 0,
			label: zones[a.zone]?.name || "Combate",
			pet
		};
	}
	const skill = skills.find((s) => s.id === a.skill);
	return {
		scene: sceneForSkill(a.skill),
		pose: heroPose(a.skill),
		foe: void 0,
		label: skill?.name || "Ofício",
		pet
	};
}
function HomePage() {
	const { S, ui } = useGame();
	const p = playerStats();
	const act = actionLabel();
	const view = visual();
	const clock = actionClock();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diorama, {
			scene: view.scene,
			pose: view.pose,
			foe: view.foe,
			label: view.label,
			pet: view.pet,
			splash: ui.splash
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "kicker",
					children: "Vale de Véspera"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "O último fogo ainda trabalha." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: "Não há herói escolhido. Você treina o ofício, e o ofício responde — mesmo com a tela fechada."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stats",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stat",
					children: ["Ataque", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.atk })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stat",
					children: ["Defesa", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.def })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stat",
					children: ["Nível total", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: totalLevel() })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "kicker",
							children: "Atividade"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: act.title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tiny",
							children: act.detail
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tag",
						children: clock ? fmtDur(clock.left) : act.kind
					})]
				}),
				S.action && clock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					value: Math.min(100, S.progress * 100),
					label: `falta ${fmtDur(clock.left)} neste ciclo`
				}) : null,
				S.action?.type === "combat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogList, { lines: S.log.slice(0, 4) }) : null,
				S.action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					onClick: stop,
					children: "Parar atividade"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn go",
					onClick: () => setTab("skills"),
					children: "Escolher um ofício"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "links",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "btn",
					onClick: () => setTab("combat"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Combate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
						className: "tiny",
						children: "Regiões e chefes"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "btn",
					onClick: () => setTab("items"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Banco" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
						className: "tiny",
						children: [
							num(usedStorage()),
							"/",
							num(storageCapacity())
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "btn",
					onClick: () => setTab("market"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Mercado" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
						className: "tiny",
						children: "Pedro e Luan"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "btn",
					onClick: () => setTab("workers"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Servos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
						className: "tiny",
						children: [S.workers.length, " na folha"]
					})]
				})
			]
		})
	] });
}
function SkillsPage() {
	const { S } = useGame();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "kicker",
				children: "Doze ofícios"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Perícias" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tiny",
				children: [
					"Nível total ",
					totalLevel(),
					". Toque um ofício para treinar. Combate sobe na luta."
				]
			})
		]
	}), [
		"Combate",
		"Coleta",
		"Produção"
	].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "kicker",
			children: g
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "skills",
			children: skills.filter((s) => s.group === g).map((s) => {
				const on = S.action?.type === "skill" && S.action.skill === s.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: `btn skill${on ? " on" : ""}`,
					onClick: () => openSkill(s.id),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillIco, { id: s.id }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: lvl(s.id) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { value: pct(s.id) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
							className: "tiny",
							children: [num(Math.max(0, need(s.id) - (S.levels[s.id]?.xp || 0))), " XP"]
						})
					]
				}, s.id);
			})
		})]
	}, g))] });
}
function DetailPage() {
	const { S, ui } = useGame();
	const id = ui.selected;
	const skill = skills.find((s) => s.id === id);
	if (!skill) return null;
	const list = nodes[id] || recipes[id];
	const eta = levelEta(id);
	const clock = actionClock();
	if (!list) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn",
				onClick: () => setTab("skills"),
				children: "Voltar aos ofícios"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillIco, { id }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
				skill.name,
				" · ",
				lvl(id)
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { value: pct(id) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Esta perícia sobe no combate, de acordo com o estilo da luta." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn go",
				onClick: () => setTab("combat"),
				children: "Ir para o combate"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "btn",
			onClick: () => setTab("skills"),
			children: "Voltar aos ofícios"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diorama, {
			scene: sceneForSkill(id),
			pose: heroPose(id),
			label: `${skill.name} · nível ${lvl(id)}`,
			splash: S.action?.type === "skill" && S.action.skill === id ? ui.splash : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: skill.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tag",
						children: [num(S.levels[id].xp), " XP"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { value: pct(id) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tiny",
					children: ["A barra de cima continua mesmo se você trocar de tela.", id === "mining" && speedMult("mining") < 1 ? ` ${gearStats[S.equip.tool || ""]?.label}.` : " Escolha um nó e deixe rodar."]
				}),
				eta != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tiny",
					children: [
						"Neste ritmo, o próximo nível chega em cerca de ",
						fmtDur(eta),
						"."
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stack",
			children: list.map((row, i) => {
				const on = S.action?.type === "skill" && S.action.skill === id && S.action.index === i;
				const locked = lvl(id) < row.level;
				const cost = "cost" in row ? row.cost : void 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "entry stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ico, {
										id: row.item,
										alt: ""
									}),
									" ",
									row.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tiny",
								children: ["Nív. ", row.level]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tiny",
							children: [
								row.seconds,
								"s · +",
								row.xp,
								" XP · ",
								cost ? "produz 1" : "+1 recurso",
								" · na mochila ",
								num(inv(row.item))
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tiny",
							children: pace(row.seconds, row.xp, id)
						}),
						itemBlurb(row.item) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tiny",
							children: itemBlurb(row.item)
						}) : null,
						cost ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tiny",
							children: ["Gasta: ", costText(cost)]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `btn${on ? " on" : " go"}`,
							disabled: locked,
							onClick: () => startSkill(id, i),
							children: locked ? "Bloqueado" : on && clock ? `Treinando · ${fmtDur(clock.left)}` : "Treinar"
						})
					]
				}, row.name);
			})
		})
	] });
}
function CombatPage() {
	const { S, ui } = useGame();
	const [focus, setFocus] = (0, import_react.useState)(0);
	const p = playerStats();
	const a = S.action?.type === "combat" ? S.action : null;
	const zone = zones[a ? a.zone : focus];
	const mon = a ? zone?.monsters[a.index] : null;
	const hpPct = mon ? Math.max(0, (S.battle?.hp ?? mon.hp) / mon.hp * 100) : 0;
	const clock = actionClock();
	const pantry = Object.entries(foods).filter(([id]) => inv(id) > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diorama, {
			scene: zoneScenes[a ? a.zone : focus] || zoneScenes[0],
			pose: "/pixel/hero-fight.png",
			foe: mon ? monsterSrc(mon.name) : void 0,
			label: mon ? mon.name : zone?.name,
			splash: a ? ui.splash : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stats",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["ATK", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.atk })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["DEF", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.def })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["MAG", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.magic })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					value: S.hp / Math.max(1, p.max) * 100,
					kind: "hp",
					label: `${S.hp}/${p.max} de vida`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "actions",
					children: [
						["attack", "Espada"],
						["ranged", "Arco"],
						["magic", "Magia"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `btn${S.style === id ? " on" : ""}`,
						onClick: () => setStyle(id),
						children: label
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `btn${S.autoCombat ? " on" : ""}`,
						onClick: () => toggleAuto("autoCombat"),
						children: ["Auto luta: ", S.autoCombat ? "sim" : "não"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `btn${S.autoFood ? " on" : ""}`,
						onClick: () => toggleAuto("autoFood"),
						children: ["Comer auto: ", S.autoFood ? "sim" : "não"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: pantry.length ? `Despensa: ${pantry.map(([id, heal]) => `${items[id]?.name} ×${inv(id)} (+${heal})`).join(" · ")}` : "Sem comida. O auto-comer não tem o que usar."
				})
			]
		}),
		mon ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: mon.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tiny",
					children: clock ? fmtDur(clock.left) : `Turno ${S.turn + 1}`
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				value: hpPct,
				kind: "danger",
				label: `${Math.max(0, Math.round(S.battle?.hp ?? mon.hp))}/${mon.hp} HP · saque ${items[mon.loot]?.name}`
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "kicker",
				children: "Registro da luta"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogList, { lines: S.log })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "kicker",
			children: "Regiões"
		}),
		zones.map((z, zi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn",
				onClick: () => setFocus(zi),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: z.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tiny",
						children: [
							"Nív. ",
							z.level,
							"+"
						]
					})]
				})
			}), S.unlocked.includes(zi) ? z.monsters.map((m, mi) => {
				const on = a?.zone === zi && a.index === mi;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "entry stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										className: "mini",
										src: monsterSrc(m.name),
										alt: ""
									}),
									" ",
									m.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tiny",
								children: ["Nív. ", m.level]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tiny",
							children: [
								"HP ",
								num(m.hp),
								" · ATK ",
								m.atk,
								" · ",
								num(m.gold),
								" ouro · ",
								items[m.loot]?.name
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `btn${on ? " on" : " go"}`,
							onClick: () => startCombat(zi, mi),
							children: on ? "Em combate" : "Enfrentar"
						})
					]
				}, m.name);
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tiny",
				children: [
					"Área bloqueada · ",
					num(z.cost),
					" ouro. A anterior precisa estar aberta."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn go",
				onClick: () => unlockZone(zi),
				children: "Desbloquear"
			})] })]
		}, z.name))
	] });
}
function ItemsPage() {
	const { S } = useGame();
	const [sel, setSel] = (0, import_react.useState)(null);
	const entries = Object.entries(S.inventory).filter(([, v]) => v > 0);
	const picked = sel && inv(sel) > 0 ? sel : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "kicker",
					children: "Banco"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Mochila" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { value: usedStorage() / Math.max(1, storageCapacity()) * 100 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tiny",
					children: [
						num(usedStorage()),
						" / ",
						num(storageCapacity()),
						" ocupado. Depósito e casa aumentam o limite."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bank",
					children: Object.keys(slotName).map((slot) => {
						const id = S.equip[slot];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `slot${id ? " on" : ""}`,
							onClick: () => id && equipItem(id),
							disabled: !id,
							children: id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ico, {
								id,
								alt: items[id]?.name || ""
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tiny",
								children: slotName[slot]
							})
						}, slot);
					})
				})
			]
		}),
		entries.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bank",
			children: entries.map(([id, qty]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: `slot${picked === id ? " on" : ""}`,
				onClick: () => setSel(id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ico, {
					id,
					alt: items[id]?.name || id
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "count",
					children: num(qty)
				})]
			}, id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "panel",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "O banco está vazio. Mine, corte ou pesque para encher as prateleiras." })
		}),
		picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
						className: "row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ico, {
								id: picked,
								alt: ""
							}),
							" ",
							items[picked]?.name || picked
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [num(inv(picked)), "×"] })]
				}),
				itemBlurb(picked) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: itemBlurb(picked)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: "Material. Serve para ofício, servo ou venda."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					children: [edible(picked) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn go",
						onClick: () => useItem(picked),
						children: ["Usar · +", foods[picked]]
					}) : null, gearable(picked) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn go",
						onClick: () => equipItem(picked),
						children: Object.values(S.equip).includes(picked) ? "Guardar" : "Equipar"
					}) : null]
				})
			]
		}) : null
	] });
}
function MarketPage() {
	const { S } = useGame();
	const [stall, setStall] = (0, import_react.useState)("pedro");
	const shop = stalls[stall];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diorama, {
			scene: "/pixel/scene-market.jpg",
			merchants: true,
			label: "Mercado de Véspera"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "kicker",
					children: "Dois mercadores, nenhum herói"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: shop.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: shop.role }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: shop.line
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tiny",
					children: [
						"Seu ouro: ",
						num(S.gold),
						". Venda aqui rende ",
						Math.round(shop.sell * 100),
						"% do preço de compra."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `btn${stall === "pedro" ? " on" : ""}`,
						onClick: () => setStall("pedro"),
						children: "Pedro · trilha"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `btn${stall === "luan" ? " on" : ""}`,
						onClick: () => setStall("luan"),
						children: "Luan · oficina"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stack",
			children: shop.goods.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "entry stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "row",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ico, {
									id: g.id,
									alt: ""
								}),
								" ",
								items[g.id]?.name || g.id
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tiny",
							children: [g.price, " ouro"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "tiny",
						children: [
							"Na mochila: ",
							num(inv(g.id)),
							" · vende por ",
							Math.floor(g.price * shop.sell)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "actions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn",
								onClick: () => marketTrade(stall, g.id, 1, "buy"),
								children: "Comprar 1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn",
								onClick: () => marketTrade(stall, g.id, 10, "buy"),
								children: "Comprar 10"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn",
								onClick: () => marketTrade(stall, g.id, 1, "sell"),
								children: "Vender 1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn",
								onClick: () => marketTrade(stall, g.id, 10, "sell"),
								children: "Vender 10"
							})
						]
					})
				]
			}, g.id))
		})
	] });
}
function WorkersPage() {
	const { S } = useGame();
	const next = hireCosts[Math.min(S.workers.length, hireCosts.length - 1)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "kicker",
					children: "Folha de pagamento"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Servos" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stats",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["Equipe", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [S.workers.length, "/6"] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["Tarefas", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: num(S.stats.workerActions || 0) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["Ouro", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: num(S.gold) })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: "Por padrão o servo pega o melhor nó que a sua perícia já abriu. Prenda um nó se ainda precisar do básico. Sem ouro, material ou espaço, ele pausa."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hire",
			children: Object.keys(workerJobs).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "btn",
				disabled: S.workers.length >= 6,
				onClick: () => hireWorker(k),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "ico",
						src: jobIcon[k],
						alt: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: workerJobs[k].name }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
						className: "tiny",
						children: [num(next), " ouro"]
					})
				]
			}, k))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stack",
			children: S.workers.length ? S.workers.map((w) => {
				const plan = workerPlan(w);
				const job = plan.job;
				const needXp = 45 * w.level * w.level;
				const left = Math.max(0, plan.tier.interval - (w.progress || 0));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "entry stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										className: "mini",
										src: heroPose(job.xp),
										alt: ""
									}),
									" ",
									w.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tag",
								children: ["Nív. ", w.level]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tiny",
							children: [
								w.active ? "Trabalhando" : "Pausado",
								" · ",
								items[plan.tier.resource]?.name,
								" · ",
								w.active ? `próximo em ${fmtDur(left)}` : "ciclo parado"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							value: Math.min(100, (w.progress || 0) / plan.tier.interval * 100),
							label: `ciclo · sua perícia está no nível ${lvl(job.xp)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								"aria-label": `Ofício de ${w.name}`,
								value: w.job,
								onChange: (e) => setWorkerJob(w.id, e.target.value),
								children: Object.keys(workerJobs).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: workerJobs[k].name
								}, k))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: `btn${w.active ? "" : " go"}`,
								onClick: () => toggleWorker(w.id),
								children: w.active ? "Pausar" : "Retomar"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": `Nó de ${w.name}`,
							value: w.tier == null || w.tier < 0 ? -1 : w.tier,
							onChange: (e) => setWorkerTier(w.id, Number(e.target.value)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: -1,
								children: "Melhor nó aberto"
							}), job.tiers.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: i,
								disabled: lvl(job.xp) < t.level,
								children: lvl(job.xp) < t.level ? `${t.name} · trancado no ${t.level}` : `${t.name} · ${items[t.resource]?.name}`
							}, t.resource))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tiny",
							children: [
								"Salário ",
								1 + Math.floor((w.level - 1) / 3),
								" ouro · ciclo ",
								plan.tier.interval,
								"s",
								plan.tier.cost ? ` · gasta ${costText(plan.tier.cost)}` : "",
								" · servo ",
								Math.round(Math.min(100, (w.xp || 0) / needXp * 100)),
								"% do nível"
							]
						})
					]
				}, w.id);
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "panel",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ninguém na folha ainda. Contrate um ofício acima." })
			})
		})
	] });
}
function PropertyPage() {
	const { S } = useGame();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diorama, {
			scene: "/pixel/scene-home.jpg",
			pose: "/pixel/hero-idle.png",
			label: "Seu terreno",
			pet: S.activePet ? petArt[S.activePet] : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "kicker",
					children: "Propriedade"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Refúgio" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stats",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["Níveis", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: Object.values(S.property).reduce((a, b) => a + b, 0) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["Banco", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
								num(usedStorage()),
								"/",
								num(storageCapacity())
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat",
							children: ["Servos", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [S.workers.length, "/6"] })]
						})
					]
				})
			]
		}),
		Object.keys(propertyDefs).map((k) => {
			const d = propertyDefs[k];
			const lv = S.property[k] || 0;
			const cost = {};
			Object.entries(d.cost).forEach(([id, n]) => {
				cost[id] = n * (lv + 1);
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "entry stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: d.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tag",
							children: [
								lv,
								"/",
								d.max
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tiny",
						children: d.desc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tiny",
						children: lv >= d.max ? "Nível máximo." : `Próxima: ${costText(cost)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn go",
						disabled: lv >= d.max,
						onClick: () => build(k),
						children: lv >= d.max ? "Máximo" : lv ? "Aprimorar" : "Construir"
					})
				]
			}, k);
		})
	] });
}
function PetsPage() {
	const { S } = useGame();
	const active = S.pets.find((p) => p.id === S.activePet);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "kicker",
				children: "Companheiros"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Mascotes" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "tiny",
				children: "Um de cada vez. O bônus vale para o vale inteiro, não para um personagem."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Ativo: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: active?.name || "Nenhum" })] })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "stack",
		children: petDefs.map((p) => {
			const owned = S.pets.some((x) => x.id === p.id);
			const on = S.activePet === p.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "entry stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "row",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									className: "mini",
									src: petArt[p.id],
									alt: ""
								}),
								" ",
								p.name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tag",
							children: owned ? on ? "junto" : "no lar" : `${num(p.cost)} ouro`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tiny",
						children: p.desc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `btn${on ? "" : " go"}`,
						onClick: () => owned ? setPet(p.id) : adoptPet(p.id),
						children: owned ? on ? "Guardar" : "Levar junto" : "Adotar"
					})
				]
			}, p.id);
		})
	})] });
}
function ContractsPage() {
	const { S } = useGame();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "kicker",
				children: "Quadro do vale"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Contratos" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tiny",
				children: [
					"Renovam com o dia do aparelho. Resgatados ",
					S.contractClaimed.length,
					"/",
					(S.dailyContracts || []).length,
					"."
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "stack",
		children: (S.dailyContracts || []).map((q) => {
			const v = S.contractCounts[q.type] || 0;
			const done = v >= q.goal;
			const claimed = S.contractClaimed.includes(q.id);
			const icon = q.type === "kills" ? "/pixel/ico-sword.png" : q.type === "workers" ? "/pixel/ico-axe.png" : "/pixel/ico-anvil.png";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "entry stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "row",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									className: "ico",
									src: icon,
									alt: ""
								}),
								" ",
								q.title
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tag",
							children: claimed ? "resgatado" : done ? "pronto" : "aberto"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tiny",
						children: q.desc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { value: Math.min(100, v / q.goal * 100) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tiny",
							children: [
								Math.min(v, q.goal),
								"/",
								q.goal,
								" · ",
								q.gold,
								" ouro + ",
								q.xp,
								" XP + 1 gema"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn go",
							disabled: !done || claimed,
							onClick: () => claimContract(q.id),
							children: claimed ? "Feito" : "Resgatar"
						})]
					})
				]
			}, q.id);
		})
	})] });
}
function MapPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "kicker",
				children: "Terras da ruína"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Mapa" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "tiny",
				children: "Seis fronteiras. Cada uma abre depois da anterior."
			})
		]
	}), zones.map((z, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "entry",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: "thumb",
				src: zoneScenes[i],
				alt: ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: z.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tag",
					children: getSave().unlocked.includes(i) ? "aberta" : "fechada"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tiny",
				children: [
					"Nível ",
					z.level,
					"+ · ",
					z.monsters.length,
					" encontros · ",
					z.monsters.at(-1)?.name
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn",
				onClick: () => setTab("combat"),
				children: "Ir ao combate"
			})
		]
	}, z.name))] });
}
function ExtrasPage() {
	const { S, ui } = useGame();
	const [code, setCode] = (0, import_react.useState)("");
	const [paste, setPaste] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "kicker",
					children: "Crônica"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "O último fogo" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Quando o sol sumiu sobre Véspera, as cinzas passaram a alimentar a terra. Cada ofício dominado é uma centelha contra o escuro. Pedro vende o que a trilha ainda dá. Luan compra o que as suas mãos fazem." })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Marcas" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Monstros derrotados: ", num(S.kills)] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Ações: ", num(S.stats.actions)] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Itens fabricados: ", num(S.stats.crafted)] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Ouro agora: ", num(S.gold)] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Salvamento" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tiny",
					children: "Grava neste navegador. Fora da tela, o progresso entra por até 8 horas — 10 com a coruja."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn go",
					onClick: () => {
						saveNow();
						notify("Progresso salvo");
					},
					children: "Salvar agora"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn",
					onClick: () => {
						const raw = exportCode();
						setCode(raw);
						navigator.clipboard?.writeText(raw).then(() => notify("Save copiado"), () => notify("Copie o código abaixo"));
					},
					children: "Exportar save"
				}),
				code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					readOnly: true,
					value: code,
					"aria-label": "Código do save"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: paste,
					placeholder: "Cole um save exportado",
					onChange: (e) => setPaste(e.target.value),
					"aria-label": "Importar save"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn",
					onClick: () => importCode(paste),
					children: "Importar save"
				}),
				ui.confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						onClick: resetGame,
						children: "Apagar mesmo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						onClick: cancelReset,
						children: "Cancelar"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					onClick: askReset,
					children: "Apagar progresso"
				})
			]
		})
	] });
}
function MorePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "kicker",
			children: "O resto do vale"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Mais" })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "links",
		children: [
			{
				tab: "market",
				title: "Mercado",
				hint: "Pedro e Luan",
				icon: "/pixel/ico-coins.png"
			},
			{
				tab: "workers",
				title: "Servos",
				hint: "Folha de ofício",
				icon: "/pixel/ico-axe.png"
			},
			{
				tab: "property",
				title: "Casa",
				hint: "Terreno e depósito",
				icon: "/pixel/ico-logs.png"
			},
			{
				tab: "map",
				title: "Mapa",
				hint: "Seis regiões",
				icon: "/pixel/ico-shield.png"
			},
			{
				tab: "pets",
				title: "Mascotes",
				hint: "Um bônus por vez",
				icon: "/pixel/ico-orb.png"
			},
			{
				tab: "contracts",
				title: "Contratos",
				hint: "Quadro do dia",
				icon: "/pixel/ico-meat.png"
			},
			{
				tab: "extras",
				title: "Crônicas",
				hint: "Save e marcas",
				icon: "/pixel/ico-flask.png"
			}
		].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			className: "btn",
			onClick: () => setTab(l.tab),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: "ico",
					src: l.icon,
					alt: ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: l.title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
					className: "tiny",
					children: l.hint
				})
			]
		}, l.tab))
	})] });
}
var pages = {
	home: HomePage,
	skills: SkillsPage,
	detail: DetailPage,
	combat: CombatPage,
	workers: WorkersPage,
	property: PropertyPage,
	market: MarketPage,
	pets: PetsPage,
	contracts: ContractsPage,
	items: ItemsPage,
	map: MapPage,
	extras: ExtrasPage,
	more: MorePage
};
var sideNav = [
	{
		id: "home",
		label: "Vale",
		icon: "/pixel/ico-coins.png"
	},
	{
		id: "skills",
		label: "Ofícios",
		icon: skillIcon("mining")
	},
	{
		id: "combat",
		label: "Combate",
		icon: "/pixel/ico-sword.png"
	},
	{
		id: "items",
		label: "Banco",
		icon: "/pixel/ico-logs.png"
	},
	{
		id: "market",
		label: "Mercado",
		icon: "/pixel/ico-pot.png"
	},
	{
		id: "workers",
		label: "Servos",
		icon: "/pixel/ico-axe.png"
	},
	{
		id: "property",
		label: "Casa",
		icon: "/pixel/ico-shield.png"
	},
	{
		id: "map",
		label: "Mapa",
		icon: "/pixel/ico-bow.png"
	},
	{
		id: "pets",
		label: "Mascotes",
		icon: "/pixel/ico-orb.png"
	},
	{
		id: "contracts",
		label: "Contratos",
		icon: "/pixel/ico-meat.png"
	},
	{
		id: "extras",
		label: "Crônicas",
		icon: "/pixel/ico-flask.png"
	}
];
var dock = [
	{
		id: "home",
		label: "Vale",
		icon: "/pixel/ico-coins.png"
	},
	{
		id: "skills",
		label: "Ofícios",
		icon: skillIcon("mining")
	},
	{
		id: "combat",
		label: "Luta",
		icon: "/pixel/ico-sword.png"
	},
	{
		id: "items",
		label: "Banco",
		icon: "/pixel/ico-logs.png"
	},
	{
		id: "more",
		label: "Mais",
		icon: "/pixel/ico-anvil.png"
	}
];
function Shell() {
	const { S, ui } = useGame();
	const p = playerStats();
	const act = actionLabel();
	const view = visual();
	const Page = pages[ui.tab] || HomePage;
	const moreOn = [
		"workers",
		"property",
		"market",
		"pets",
		"contracts",
		"map",
		"extras",
		"more"
	].includes(ui.tab);
	const hp = Math.max(0, S.hp / Math.max(1, p.max) * 100);
	const clock = actionClock();
	const jump = () => {
		const a = getSave().action;
		if (!a) setTab("skills");
		else if (a.type === "combat") setTab("combat");
		else openSkill(a.skill);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "top-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "ASHES OF RUIN" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Idle Chronicles" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hp",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
								S.hp,
								"/",
								p.max
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "track hp",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${hp}%` } })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "res",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								className: "ico",
								src: "/pixel/ico-coins.png",
								alt: ""
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: num(S.gold) })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "activity",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "activity-jump",
						onClick: jump,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							className: "mini",
							src: view.pose,
							alt: ""
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "who",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: act.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "eta",
										children: clock ? fmtDur(clock.left) : "parado"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "track",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { width: `${Math.max(0, Math.min(100, S.progress * 100))}%` } })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: ui.pulse ? "pulse" : "hint",
									children: ui.pulse || (S.action ? "Toque para abrir o ofício" : "Escolha um ofício")
								}, ui.pulse ? ui.pulseN : "idle")
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						onClick: stop,
						disabled: !S.action,
						children: "Parar"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "workspace",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "side",
					"aria-label": "Seções",
					children: sideNav.map((item) => {
						const on = ui.tab === item.id || ui.tab === "detail" && item.id === "skills";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: on ? "on" : "",
							onClick: () => setTab(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.icon,
								alt: ""
							}), item.label]
						}, item.id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "screen",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock",
				"aria-label": "Navegação",
				children: dock.map((item) => {
					const on = item.id === "more" ? moreOn : ui.tab === item.id || ui.tab === "detail" && item.id === "skills";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: on ? "on" : "",
						onClick: () => setTab(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.icon,
							alt: ""
						}), item.label]
					}, item.id);
				})
			}),
			ui.toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "toast",
				role: "status",
				children: ui.toast
			}) : null
		]
	});
}
function GameApp() {
	(0, import_react.useEffect)(() => {
		boot();
		let last = performance.now();
		let raf = 0;
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			frame(dt);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		const timer = window.setInterval(saveNow, 5e3);
		const hide = () => {
			if (document.hidden) saveNow();
			else catchUp();
		};
		document.addEventListener("visibilitychange", hide);
		window.addEventListener("beforeunload", saveNow);
		return () => {
			cancelAnimationFrame(raf);
			window.clearInterval(timer);
			document.removeEventListener("visibilitychange", hide);
			window.removeEventListener("beforeunload", saveNow);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
var SplitComponent = GameApp;
//#endregion
export { SplitComponent as component };
